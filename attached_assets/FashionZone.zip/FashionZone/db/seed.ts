import { db } from "./index";
import {
  users,
  categories,
  products,
  colors,
  sizes,
  productVariants,
  categoryEnum
} from "@shared/schema";
import { scrypt, randomBytes } from "crypto";
import { promisify } from "util";

const scryptAsync = promisify(scrypt);

async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

async function seed() {
  try {
    console.log("Seeding database...");

    // Seed admin user
    const existingUser = await db.query.users.findFirst({
      where: (users, { eq }) => eq(users.username, "admin")
    });

    if (!existingUser) {
      console.log("Creating admin user...");
      await db.insert(users).values({
        username: "admin",
        password: await hashPassword("admin123"),
        email: "admin@fashionhub.com",
        firstName: "Admin",
        lastName: "User"
      });
    }

    // Seed colors
    const colorData = [
      { name: "Black", value: "#000000" },
      { name: "White", value: "#FFFFFF" },
      { name: "Red", value: "#FF0000" },
      { name: "Blue", value: "#0000FF" },
      { name: "Green", value: "#008000" },
      { name: "Yellow", value: "#FFFF00" },
      { name: "Brown", value: "#A52A2A" },
      { name: "Gray", value: "#808080" },
      { name: "Beige", value: "#F5F5DC" },
      { name: "Navy", value: "#000080" },
      { name: "Pink", value: "#FFC0CB" },
      { name: "Purple", value: "#800080" }
    ];

    const existingColors = await db.query.colors.findMany();
    if (existingColors.length === 0) {
      console.log("Seeding colors...");
      await db.insert(colors).values(colorData);
    }

    // Seed sizes
    const womenSizeData = [
      { name: "XS", value: "XS", categoryType: "women" },
      { name: "S", value: "S", categoryType: "women" },
      { name: "M", value: "M", categoryType: "women" },
      { name: "L", value: "L", categoryType: "women" },
      { name: "XL", value: "XL", categoryType: "women" }
    ];

    const menSizeData = [
      { name: "S", value: "S", categoryType: "men" },
      { name: "M", value: "M", categoryType: "men" },
      { name: "L", value: "L", categoryType: "men" },
      { name: "XL", value: "XL", categoryType: "men" },
      { name: "XXL", value: "XXL", categoryType: "men" }
    ];

    const childrenSizeData = [
      { name: "2-3 years", value: "2-3", categoryType: "children" },
      { name: "4-5 years", value: "4-5", categoryType: "children" },
      { name: "6-7 years", value: "6-7", categoryType: "children" },
      { name: "8-9 years", value: "8-9", categoryType: "children" },
      { name: "10-11 years", value: "10-11", categoryType: "children" }
    ];

    const footwearSizeData = [
      { name: "36", value: "36", categoryType: "women" },
      { name: "37", value: "37", categoryType: "women" },
      { name: "38", value: "38", categoryType: "women" },
      { name: "39", value: "39", categoryType: "women" },
      { name: "40", value: "40", categoryType: "women" },
      { name: "41", value: "41", categoryType: "men" },
      { name: "42", value: "42", categoryType: "men" },
      { name: "43", value: "43", categoryType: "men" },
      { name: "44", value: "44", categoryType: "men" },
      { name: "45", value: "45", categoryType: "men" }
    ];

    const existingSizes = await db.query.sizes.findMany();
    if (existingSizes.length === 0) {
      console.log("Seeding sizes...");
      await db.insert(sizes).values([
        ...womenSizeData,
        ...menSizeData,
        ...childrenSizeData,
        ...footwearSizeData
      ]);
    }

    // Seed categories
    const mainCategories = [
      {
        name: "Women",
        slug: "women",
        description: "Women's clothing collection",
        imageUrl: "https://images.unsplash.com/photo-1594223274512-ad4803739b7c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=1000"
      },
      {
        name: "Men",
        slug: "men",
        description: "Men's clothing collection",
        imageUrl: "https://images.unsplash.com/photo-1617127365659-c47fa864d8bc?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=1000"
      },
      {
        name: "Children",
        slug: "children",
        description: "Children's clothing collection",
        imageUrl: "https://pixabay.com/get/g08db37d367a82195fb0b2dacf43223c603c329b82e7f807962aab404c17598c859adefa7487a30265b25eeeff7c49be3daacc20c99652a466aa822d2a65af47c_1280.jpg"
      },
      {
        name: "Accessories",
        slug: "accessories",
        description: "Fashion accessories",
        imageUrl: "https://images.unsplash.com/photo-1576053139778-7e32f2ae3cfd?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=1000"
      }
    ];

    const existingMainCategories = await db.query.categories.findMany({
      where: (categories, { isNull }) => isNull(categories.parentId)
    });

    if (existingMainCategories.length === 0) {
      console.log("Seeding main categories...");
      await db.insert(categories).values(mainCategories);
    }

    // Fetch categories to get IDs for subcategories
    const womenCategory = await db.query.categories.findFirst({
      where: (categories, { eq }) => eq(categories.slug, "women")
    });

    const menCategory = await db.query.categories.findFirst({
      where: (categories, { eq }) => eq(categories.slug, "men")
    });

    const childrenCategory = await db.query.categories.findFirst({
      where: (categories, { eq }) => eq(categories.slug, "children")
    });

    const accessoriesCategory = await db.query.categories.findFirst({
      where: (categories, { eq }) => eq(categories.slug, "accessories")
    });

    // Seed subcategories
    const womenSubcategories = [
      {
        name: "Dresses",
        slug: "women-dresses",
        description: "Women's dresses",
        parentId: womenCategory?.id
      },
      {
        name: "Tops",
        slug: "women-tops",
        description: "Women's tops and blouses",
        parentId: womenCategory?.id
      },
      {
        name: "Pants",
        slug: "women-pants",
        description: "Women's pants and jeans",
        parentId: womenCategory?.id
      },
      {
        name: "Outerwear",
        slug: "women-outerwear",
        description: "Women's jackets and coats",
        parentId: womenCategory?.id
      }
    ];

    const menSubcategories = [
      {
        name: "Shirts",
        slug: "men-shirts",
        description: "Men's shirts",
        parentId: menCategory?.id
      },
      {
        name: "Pants",
        slug: "men-pants",
        description: "Men's pants and jeans",
        parentId: menCategory?.id
      },
      {
        name: "Outerwear",
        slug: "men-outerwear",
        description: "Men's jackets and coats",
        parentId: menCategory?.id
      },
      {
        name: "T-shirts",
        slug: "men-tshirts",
        description: "Men's t-shirts and polos",
        parentId: menCategory?.id
      }
    ];

    const childrenSubcategories = [
      {
        name: "Boys",
        slug: "children-boys",
        description: "Boys' clothing",
        parentId: childrenCategory?.id
      },
      {
        name: "Girls",
        slug: "children-girls",
        description: "Girls' clothing",
        parentId: childrenCategory?.id
      }
    ];

    const existingSubcategories = await db.query.categories.findMany({
      where: (categories, { isNotNull }) => isNotNull(categories.parentId)
    });

    if (existingSubcategories.length === 0 && womenCategory && menCategory && childrenCategory) {
      console.log("Seeding subcategories...");
      await db.insert(categories).values([
        ...womenSubcategories,
        ...menSubcategories,
        ...childrenSubcategories
      ]);
    }

    // Seed products
    const existingProducts = await db.query.products.findMany();
    if (existingProducts.length === 0) {
      console.log("Seeding products...");

      // Fetch subcategories
      const womenDressesCategory = await db.query.categories.findFirst({
        where: (categories, { eq }) => eq(categories.slug, "women-dresses")
      });

      const womenTopsCategory = await db.query.categories.findFirst({
        where: (categories, { eq }) => eq(categories.slug, "women-tops")
      });

      const menOuterwearCategory = await db.query.categories.findFirst({
        where: (categories, { eq }) => eq(categories.slug, "men-outerwear")
      });

      const menShirtsCategory = await db.query.categories.findFirst({
        where: (categories, { eq }) => eq(categories.slug, "men-shirts")
      });

      // Women's products
      const womenProducts = [
        {
          name: "Floral Print Dress",
          slug: "floral-print-dress",
          description: "Beautiful floral print dress perfect for summer occasions.",
          price: "3600",
          compareAtPrice: "4800",
          imageUrl: "https://images.unsplash.com/photo-1572804013309-59a88b7e92f1?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&h=1500",
          categoryId: womenDressesCategory?.id,
          inStock: true,
          isNew: false,
          isFeatured: true,
          rating: "4.8",
          categoryType: "women"
        },
        {
          name: "Balloon Sleeve Blouse",
          slug: "balloon-sleeve-blouse",
          description: "Elegant blouse with balloon sleeves, perfect for both casual and formal occasions.",
          price: "2800",
          imageUrl: "https://images.unsplash.com/photo-1564257631407-4deb1f99d992?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&h=1500",
          categoryId: womenTopsCategory?.id,
          inStock: true,
          isNew: true,
          isFeatured: false,
          rating: "4.9",
          categoryType: "women"
        },
        {
          name: "Belted Midi Dress",
          slug: "belted-midi-dress",
          description: "Stylish midi dress with a belt, versatile for different occasions.",
          price: "4200",
          imageUrl: "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&h=1500",
          categoryId: womenDressesCategory?.id,
          inStock: true,
          isNew: true,
          isFeatured: false,
          rating: "4.7",
          categoryType: "women"
        },
        {
          name: "Linen Jumpsuit",
          slug: "linen-jumpsuit",
          description: "Comfortable and stylish linen jumpsuit for warm weather.",
          price: "5400",
          imageUrl: "https://images.unsplash.com/photo-1496217590455-aa63a8350eea?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&h=1500",
          categoryId: womenCategory?.id,
          inStock: true,
          isNew: true,
          isFeatured: false,
          rating: "4.6",
          categoryType: "women"
        }
      ];

      // Men's products
      const menProducts = [
        {
          name: "Leather Jacket",
          slug: "leather-jacket",
          description: "Classic leather jacket for men, perfect for a stylish casual look.",
          price: "8900",
          imageUrl: "https://images.unsplash.com/photo-1591047139829-d91aecb6caea?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&h=1500",
          categoryId: menOuterwearCategory?.id,
          inStock: true,
          isNew: false,
          isFeatured: true,
          rating: "4.7",
          categoryType: "men"
        },
        {
          name: "Cotton Shirt",
          slug: "cotton-shirt",
          description: "Comfortable cotton shirt, perfect for any occasion.",
          price: "3100",
          imageUrl: "https://images.unsplash.com/photo-1603252109303-2751441dd157?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&h=1500",
          categoryId: menShirtsCategory?.id,
          inStock: true,
          isNew: true,
          isFeatured: false,
          rating: "4.5",
          categoryType: "men"
        },
        {
          name: "Slim Fit Jeans",
          slug: "slim-fit-jeans",
          description: "Stylish slim fit jeans for a modern look.",
          price: "3600",
          imageUrl: "https://images.unsplash.com/photo-1555689502-c4b22d76c56f?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&h=1500",
          categoryId: menCategory?.id,
          inStock: true,
          isNew: false,
          isFeatured: true,
          rating: "4.6",
          categoryType: "men"
        },
        {
          name: "Oversized Sweater",
          slug: "oversized-sweater",
          description: "Warm and comfortable oversized sweater for cold weather.",
          price: "3900",
          imageUrl: "https://images.unsplash.com/photo-1516826957135-700dedea698c?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&h=1500",
          categoryId: menCategory?.id,
          inStock: true,
          isNew: true,
          isFeatured: false,
          rating: "4.4",
          categoryType: "men"
        }
      ];

      // Insert products
      await db.insert(products).values([...womenProducts, ...menProducts]);

      // Get product IDs for variants
      const productEntities = await db.query.products.findMany();
      
      // Get color and size IDs
      const blackColor = await db.query.colors.findFirst({
        where: (colors, { eq }) => eq(colors.name, "Black")
      });
      
      const whiteColor = await db.query.colors.findFirst({
        where: (colors, { eq }) => eq(colors.name, "White")
      });
      
      const redColor = await db.query.colors.findFirst({
        where: (colors, { eq }) => eq(colors.name, "Red")
      });
      
      const blueColor = await db.query.colors.findFirst({
        where: (colors, { eq }) => eq(colors.name, "Blue")
      });
      
      const brownColor = await db.query.colors.findFirst({
        where: (colors, { eq }) => eq(colors.name, "Brown")
      });
      
      const greenColor = await db.query.colors.findFirst({
        where: (colors, { eq }) => eq(colors.name, "Green")
      });
      
      const beigeColor = await db.query.colors.findFirst({
        where: (colors, { eq }) => eq(colors.name, "Beige")
      });
      
      const grayColor = await db.query.colors.findFirst({
        where: (colors, { eq }) => eq(colors.name, "Gray")
      });

      const sizesXS = await db.query.sizes.findFirst({
        where: (sizes, { and, eq }) => and(eq(sizes.name, "XS"), eq(sizes.categoryType, "women"))
      });
      
      const sizesS = await db.query.sizes.findFirst({
        where: (sizes, { and, eq }) => and(eq(sizes.name, "S"), eq(sizes.categoryType, "women"))
      });
      
      const sizesM = await db.query.sizes.findFirst({
        where: (sizes, { and, eq }) => and(eq(sizes.name, "M"), eq(sizes.categoryType, "women"))
      });
      
      const sizesL = await db.query.sizes.findFirst({
        where: (sizes, { and, eq }) => and(eq(sizes.name, "L"), eq(sizes.categoryType, "women"))
      });
      
      const sizesXL = await db.query.sizes.findFirst({
        where: (sizes, { and, eq }) => and(eq(sizes.name, "XL"), eq(sizes.categoryType, "women"))
      });

      const menSizesS = await db.query.sizes.findFirst({
        where: (sizes, { and, eq }) => and(eq(sizes.name, "S"), eq(sizes.categoryType, "men"))
      });
      
      const menSizesM = await db.query.sizes.findFirst({
        where: (sizes, { and, eq }) => and(eq(sizes.name, "M"), eq(sizes.categoryType, "men"))
      });
      
      const menSizesL = await db.query.sizes.findFirst({
        where: (sizes, { and, eq }) => and(eq(sizes.name, "L"), eq(sizes.categoryType, "men"))
      });
      
      const menSizesXL = await db.query.sizes.findFirst({
        where: (sizes, { and, eq }) => and(eq(sizes.name, "XL"), eq(sizes.categoryType, "men"))
      });
      
      const menSizesXXL = await db.query.sizes.findFirst({
        where: (sizes, { and, eq }) => and(eq(sizes.name, "XXL"), eq(sizes.categoryType, "men"))
      });

      // Create variants data
      const variantsData = [];

      // Find products for variants
      const floralDress = productEntities.find(p => p.slug === "floral-print-dress");
      const balloonBlouse = productEntities.find(p => p.slug === "balloon-sleeve-blouse");
      const beltedDress = productEntities.find(p => p.slug === "belted-midi-dress");
      const linenJumpsuit = productEntities.find(p => p.slug === "linen-jumpsuit");
      const leatherJacket = productEntities.find(p => p.slug === "leather-jacket");
      const cottonShirt = productEntities.find(p => p.slug === "cotton-shirt");
      const slimJeans = productEntities.find(p => p.slug === "slim-fit-jeans");
      const oversizedSweater = productEntities.find(p => p.slug === "oversized-sweater");

      // Floral Dress variants
      if (floralDress && sizesXS && sizesS && sizesM && sizesL && sizesXL && redColor && blueColor) {
        variantsData.push(
          {
            productId: floralDress.id,
            colorId: redColor.id,
            sizeId: sizesXS.id,
            quantity: 10,
            sku: "FD-RED-XS"
          },
          {
            productId: floralDress.id,
            colorId: redColor.id,
            sizeId: sizesS.id,
            quantity: 15,
            sku: "FD-RED-S"
          },
          {
            productId: floralDress.id,
            colorId: redColor.id,
            sizeId: sizesM.id,
            quantity: 20,
            sku: "FD-RED-M"
          },
          {
            productId: floralDress.id,
            colorId: redColor.id,
            sizeId: sizesL.id,
            quantity: 15,
            sku: "FD-RED-L"
          },
          {
            productId: floralDress.id,
            colorId: blueColor.id,
            sizeId: sizesXS.id,
            quantity: 10,
            sku: "FD-BLUE-XS"
          },
          {
            productId: floralDress.id,
            colorId: blueColor.id,
            sizeId: sizesS.id,
            quantity: 15,
            sku: "FD-BLUE-S"
          },
          {
            productId: floralDress.id,
            colorId: blueColor.id,
            sizeId: sizesM.id,
            quantity: 20,
            sku: "FD-BLUE-M"
          },
          {
            productId: floralDress.id,
            colorId: blueColor.id,
            sizeId: sizesL.id,
            quantity: 15,
            sku: "FD-BLUE-L"
          }
        );
      }

      // Balloon Blouse variants
      if (balloonBlouse && sizesXS && sizesS && sizesM && sizesL && whiteColor) {
        variantsData.push(
          {
            productId: balloonBlouse.id,
            colorId: whiteColor.id,
            sizeId: sizesXS.id,
            quantity: 10,
            sku: "BB-WHITE-XS"
          },
          {
            productId: balloonBlouse.id,
            colorId: whiteColor.id,
            sizeId: sizesS.id,
            quantity: 15,
            sku: "BB-WHITE-S"
          },
          {
            productId: balloonBlouse.id,
            colorId: whiteColor.id,
            sizeId: sizesM.id,
            quantity: 20,
            sku: "BB-WHITE-M"
          },
          {
            productId: balloonBlouse.id,
            colorId: whiteColor.id,
            sizeId: sizesL.id,
            quantity: 15,
            sku: "BB-WHITE-L"
          }
        );
      }

      // Leather Jacket variants
      if (leatherJacket && menSizesS && menSizesM && menSizesL && menSizesXL && blackColor && brownColor) {
        variantsData.push(
          {
            productId: leatherJacket.id,
            colorId: blackColor.id,
            sizeId: menSizesS.id,
            quantity: 5,
            sku: "LJ-BLACK-S"
          },
          {
            productId: leatherJacket.id,
            colorId: blackColor.id,
            sizeId: menSizesM.id,
            quantity: 10,
            sku: "LJ-BLACK-M"
          },
          {
            productId: leatherJacket.id,
            colorId: blackColor.id,
            sizeId: menSizesL.id,
            quantity: 10,
            sku: "LJ-BLACK-L"
          },
          {
            productId: leatherJacket.id,
            colorId: blackColor.id,
            sizeId: menSizesXL.id,
            quantity: 5,
            sku: "LJ-BLACK-XL"
          },
          {
            productId: leatherJacket.id,
            colorId: brownColor.id,
            sizeId: menSizesS.id,
            quantity: 5,
            sku: "LJ-BROWN-S"
          },
          {
            productId: leatherJacket.id,
            colorId: brownColor.id,
            sizeId: menSizesM.id,
            quantity: 10,
            sku: "LJ-BROWN-M"
          },
          {
            productId: leatherJacket.id,
            colorId: brownColor.id,
            sizeId: menSizesL.id,
            quantity: 10,
            sku: "LJ-BROWN-L"
          },
          {
            productId: leatherJacket.id,
            colorId: brownColor.id,
            sizeId: menSizesXL.id,
            quantity: 5,
            sku: "LJ-BROWN-XL"
          }
        );
      }

      // Belted Dress variants
      if (beltedDress && sizesXS && sizesS && sizesM && sizesL && blackColor && blueColor) {
        variantsData.push(
          {
            productId: beltedDress.id,
            colorId: blackColor.id,
            sizeId: sizesXS.id,
            quantity: 8,
            sku: "BD-BLACK-XS"
          },
          {
            productId: beltedDress.id,
            colorId: blackColor.id,
            sizeId: sizesS.id,
            quantity: 12,
            sku: "BD-BLACK-S"
          },
          {
            productId: beltedDress.id,
            colorId: blackColor.id,
            sizeId: sizesM.id,
            quantity: 15,
            sku: "BD-BLACK-M"
          },
          {
            productId: beltedDress.id,
            colorId: blackColor.id,
            sizeId: sizesL.id,
            quantity: 10,
            sku: "BD-BLACK-L"
          },
          {
            productId: beltedDress.id,
            colorId: blueColor.id,
            sizeId: sizesXS.id,
            quantity: 8,
            sku: "BD-BLUE-XS"
          },
          {
            productId: beltedDress.id,
            colorId: blueColor.id,
            sizeId: sizesS.id,
            quantity: 12,
            sku: "BD-BLUE-S"
          },
          {
            productId: beltedDress.id,
            colorId: blueColor.id,
            sizeId: sizesM.id,
            quantity: 15,
            sku: "BD-BLUE-M"
          },
          {
            productId: beltedDress.id,
            colorId: blueColor.id,
            sizeId: sizesL.id,
            quantity: 10,
            sku: "BD-BLUE-L"
          }
        );
      }

      // Linen Jumpsuit variants
      if (linenJumpsuit && sizesXS && sizesS && sizesM && sizesL && beigeColor && blackColor) {
        variantsData.push(
          {
            productId: linenJumpsuit.id,
            colorId: beigeColor.id,
            sizeId: sizesXS.id,
            quantity: 5,
            sku: "LJ-BEIGE-XS"
          },
          {
            productId: linenJumpsuit.id,
            colorId: beigeColor.id,
            sizeId: sizesS.id,
            quantity: 10,
            sku: "LJ-BEIGE-S"
          },
          {
            productId: linenJumpsuit.id,
            colorId: beigeColor.id,
            sizeId: sizesM.id,
            quantity: 12,
            sku: "LJ-BEIGE-M"
          },
          {
            productId: linenJumpsuit.id,
            colorId: beigeColor.id,
            sizeId: sizesL.id,
            quantity: 8,
            sku: "LJ-BEIGE-L"
          },
          {
            productId: linenJumpsuit.id,
            colorId: blackColor.id,
            sizeId: sizesXS.id,
            quantity: 5,
            sku: "LJ-BLACK-XS"
          },
          {
            productId: linenJumpsuit.id,
            colorId: blackColor.id,
            sizeId: sizesS.id,
            quantity: 10,
            sku: "LJ-BLACK-S"
          },
          {
            productId: linenJumpsuit.id,
            colorId: blackColor.id,
            sizeId: sizesM.id,
            quantity: 12,
            sku: "LJ-BLACK-M"
          },
          {
            productId: linenJumpsuit.id,
            colorId: blackColor.id,
            sizeId: sizesL.id,
            quantity: 8,
            sku: "LJ-BLACK-L"
          }
        );
      }

      // Cotton Shirt variants
      if (cottonShirt && menSizesS && menSizesM && menSizesL && menSizesXL && whiteColor && blueColor) {
        variantsData.push(
          {
            productId: cottonShirt.id,
            colorId: whiteColor.id,
            sizeId: menSizesS.id,
            quantity: 10,
            sku: "CS-WHITE-S"
          },
          {
            productId: cottonShirt.id,
            colorId: whiteColor.id,
            sizeId: menSizesM.id,
            quantity: 15,
            sku: "CS-WHITE-M"
          },
          {
            productId: cottonShirt.id,
            colorId: whiteColor.id,
            sizeId: menSizesL.id,
            quantity: 15,
            sku: "CS-WHITE-L"
          },
          {
            productId: cottonShirt.id,
            colorId: whiteColor.id,
            sizeId: menSizesXL.id,
            quantity: 10,
            sku: "CS-WHITE-XL"
          },
          {
            productId: cottonShirt.id,
            colorId: blueColor.id,
            sizeId: menSizesS.id,
            quantity: 10,
            sku: "CS-BLUE-S"
          },
          {
            productId: cottonShirt.id,
            colorId: blueColor.id,
            sizeId: menSizesM.id,
            quantity: 15,
            sku: "CS-BLUE-M"
          },
          {
            productId: cottonShirt.id,
            colorId: blueColor.id,
            sizeId: menSizesL.id,
            quantity: 15,
            sku: "CS-BLUE-L"
          },
          {
            productId: cottonShirt.id,
            colorId: blueColor.id,
            sizeId: menSizesXL.id,
            quantity: 10,
            sku: "CS-BLUE-XL"
          }
        );
      }

      // Slim Fit Jeans variants
      if (slimJeans && menSizesS && menSizesM && menSizesL && menSizesXL && blueColor) {
        variantsData.push(
          {
            productId: slimJeans.id,
            colorId: blueColor.id,
            sizeId: menSizesS.id,
            quantity: 10,
            sku: "SJ-BLUE-S"
          },
          {
            productId: slimJeans.id,
            colorId: blueColor.id,
            sizeId: menSizesM.id,
            quantity: 15,
            sku: "SJ-BLUE-M"
          },
          {
            productId: slimJeans.id,
            colorId: blueColor.id,
            sizeId: menSizesL.id,
            quantity: 15,
            sku: "SJ-BLUE-L"
          },
          {
            productId: slimJeans.id,
            colorId: blueColor.id,
            sizeId: menSizesXL.id,
            quantity: 10,
            sku: "SJ-BLUE-XL"
          }
        );
      }

      // Oversized Sweater variants
      if (oversizedSweater && menSizesS && menSizesM && menSizesL && menSizesXL && greenColor && brownColor && grayColor) {
        variantsData.push(
          {
            productId: oversizedSweater.id,
            colorId: greenColor.id,
            sizeId: menSizesS.id,
            quantity: 8,
            sku: "OS-GREEN-S"
          },
          {
            productId: oversizedSweater.id,
            colorId: greenColor.id,
            sizeId: menSizesM.id,
            quantity: 12,
            sku: "OS-GREEN-M"
          },
          {
            productId: oversizedSweater.id,
            colorId: greenColor.id,
            sizeId: menSizesL.id,
            quantity: 12,
            sku: "OS-GREEN-L"
          },
          {
            productId: oversizedSweater.id,
            colorId: greenColor.id,
            sizeId: menSizesXL.id,
            quantity: 8,
            sku: "OS-GREEN-XL"
          },
          {
            productId: oversizedSweater.id,
            colorId: brownColor.id,
            sizeId: menSizesS.id,
            quantity: 8,
            sku: "OS-BROWN-S"
          },
          {
            productId: oversizedSweater.id,
            colorId: brownColor.id,
            sizeId: menSizesM.id,
            quantity: 12,
            sku: "OS-BROWN-M"
          },
          {
            productId: oversizedSweater.id,
            colorId: brownColor.id,
            sizeId: menSizesL.id,
            quantity: 12,
            sku: "OS-BROWN-L"
          },
          {
            productId: oversizedSweater.id,
            colorId: brownColor.id,
            sizeId: menSizesXL.id,
            quantity: 8,
            sku: "OS-BROWN-XL"
          },
          {
            productId: oversizedSweater.id,
            colorId: grayColor.id,
            sizeId: menSizesS.id,
            quantity: 8,
            sku: "OS-GRAY-S"
          },
          {
            productId: oversizedSweater.id,
            colorId: grayColor.id,
            sizeId: menSizesM.id,
            quantity: 12,
            sku: "OS-GRAY-M"
          },
          {
            productId: oversizedSweater.id,
            colorId: grayColor.id,
            sizeId: menSizesL.id,
            quantity: 12,
            sku: "OS-GRAY-L"
          },
          {
            productId: oversizedSweater.id,
            colorId: grayColor.id,
            sizeId: menSizesXL.id,
            quantity: 8,
            sku: "OS-GRAY-XL"
          }
        );
      }

      // Insert product variants
      console.log("Seeding product variants...");
      if (variantsData.length > 0) {
        await db.insert(productVariants).values(variantsData);
      }
    }

    console.log("Database seeding completed successfully!");
  } catch (error) {
    console.error("Error seeding database:", error);
  }
}

seed();
