import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { cartItems, orderItems, insertUserSchema } from "@shared/schema";
import { eq } from "drizzle-orm";
import { db } from "../db";

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up authentication routes
  setupAuth(app);

  // API prefix
  const apiPrefix = "/api";

  // Categories routes
  app.get(`${apiPrefix}/categories`, async (req, res) => {
    try {
      const categories = await storage.getCategories();
      res.json(categories);
    } catch (error) {
      console.error("Error fetching categories:", error);
      res.status(500).json({ message: "Failed to fetch categories" });
    }
  });

  app.get(`${apiPrefix}/categories/:slug`, async (req, res) => {
    try {
      const category = await storage.getCategoryBySlug(req.params.slug);
      res.json(category);
    } catch (error) {
      console.error(`Error fetching category ${req.params.slug}:`, error);
      res.status(404).json({ message: "Category not found" });
    }
  });

  // Products routes
  app.get(`${apiPrefix}/products`, async (req, res) => {
    try {
      const {
        categoryType,
        categoryId,
        isNew,
        isFeatured,
        limit,
        page,
        sortBy,
        search,
        minPrice,
        maxPrice
      } = req.query;

      const options: any = {};
      
      if (categoryType) options.categoryType = categoryType as string;
      if (categoryId) options.categoryId = parseInt(categoryId as string);
      if (isNew !== undefined) options.isNew = isNew === 'true';
      if (isFeatured !== undefined) options.isFeatured = isFeatured === 'true';
      if (limit) options.limit = parseInt(limit as string);
      if (sortBy) options.sortBy = sortBy as string;
      if (search) options.search = search as string;
      if (minPrice) options.minPrice = parseFloat(minPrice as string);
      if (maxPrice) options.maxPrice = parseFloat(maxPrice as string);
      
      // Calculate offset for pagination
      if (page && limit) {
        const pageNum = parseInt(page as string);
        const limitNum = parseInt(limit as string);
        options.offset = (pageNum - 1) * limitNum;
      }

      const products = await storage.getProducts(options);
      
      // Get total count for pagination
      const totalCount = await storage.getProducts({ 
        categoryType: options.categoryType,
        categoryId: options.categoryId, 
        isNew: options.isNew,
        isFeatured: options.isFeatured,
        search: options.search,
        minPrice: options.minPrice,
        maxPrice: options.maxPrice
      });
      
      res.json({
        products,
        total: totalCount.length,
        page: page ? parseInt(page as string) : 1,
        limit: limit ? parseInt(limit as string) : totalCount.length
      });
    } catch (error) {
      console.error("Error fetching products:", error);
      res.status(500).json({ message: "Failed to fetch products" });
    }
  });

  app.get(`${apiPrefix}/products/:slug`, async (req, res) => {
    try {
      const product = await storage.getProductBySlug(req.params.slug);
      res.json(product);
    } catch (error) {
      console.error(`Error fetching product ${req.params.slug}:`, error);
      res.status(404).json({ message: "Product not found" });
    }
  });

  // Cart routes
  // Get or create cart
  app.get(`${apiPrefix}/cart`, async (req, res) => {
    try {
      let cart;

      if (req.isAuthenticated()) {
        // User is logged in, get or create cart by user ID
        cart = await storage.getCartByUserId(req.user.id);
        
        if (!cart) {
          cart = await storage.createCart({ userId: req.user.id });
          // Return empty cart
          return res.json({ ...cart, cartItems: [] });
        }
      } else if (req.session.id) {
        // User is not logged in, get or create cart by session ID
        cart = await storage.getCartBySessionId(req.session.id);
        
        if (!cart) {
          cart = await storage.createCart({ sessionId: req.session.id });
          // Return empty cart
          return res.json({ ...cart, cartItems: [] });
        }
      } else {
        return res.status(400).json({ message: "Unable to identify session" });
      }

      // Get full cart with items
      const fullCart = await storage.getCartWithItems(cart.id);
      res.json(fullCart);

    } catch (error) {
      console.error("Error retrieving cart:", error);
      res.status(500).json({ message: "Failed to retrieve cart" });
    }
  });

  // Add item to cart
  app.post(`${apiPrefix}/cart/items`, async (req, res) => {
    try {
      let cart;

      if (req.isAuthenticated()) {
        // User is logged in, get or create cart by user ID
        cart = await storage.getCartByUserId(req.user.id);
        
        if (!cart) {
          cart = await storage.createCart({ userId: req.user.id });
        }
      } else if (req.session.id) {
        // User is not logged in, get or create cart by session ID
        cart = await storage.getCartBySessionId(req.session.id);
        
        if (!cart) {
          cart = await storage.createCart({ sessionId: req.session.id });
        }
      } else {
        return res.status(400).json({ message: "Unable to identify session" });
      }

      const { productId, variantId, quantity } = req.body;

      if (!productId || !quantity) {
        return res.status(400).json({ message: "Product ID and quantity are required" });
      }

      await storage.addItemToCart(cart.id, { 
        productId: parseInt(productId), 
        variantId: variantId ? parseInt(variantId) : undefined, 
        quantity: parseInt(quantity) 
      });

      // Return updated cart
      const updatedCart = await storage.getCartWithItems(cart.id);
      res.json(updatedCart);

    } catch (error) {
      console.error("Error adding item to cart:", error);
      res.status(500).json({ message: "Failed to add item to cart" });
    }
  });

  // Update cart item
  app.put(`${apiPrefix}/cart/items/:id`, async (req, res) => {
    try {
      const { quantity } = req.body;
      const cartItemId = parseInt(req.params.id);

      if (quantity <= 0) {
        await storage.removeCartItem(cartItemId);
      } else {
        await storage.updateCartItem(cartItemId, quantity);
      }

      // Determine which cart to return
      let cartId;
      if (req.isAuthenticated()) {
        const userCart = await storage.getCartByUserId(req.user.id);
        cartId = userCart?.id;
      } else if (req.session.id) {
        const sessionCart = await storage.getCartBySessionId(req.session.id);
        cartId = sessionCart?.id;
      }

      if (cartId) {
        const updatedCart = await storage.getCartWithItems(cartId);
        res.json(updatedCart);
      } else {
        res.status(404).json({ message: "Cart not found" });
      }

    } catch (error) {
      console.error("Error updating cart item:", error);
      res.status(500).json({ message: "Failed to update cart item" });
    }
  });

  // Remove cart item
  app.delete(`${apiPrefix}/cart/items/:id`, async (req, res) => {
    try {
      const cartItemId = parseInt(req.params.id);
      await storage.removeCartItem(cartItemId);

      // Determine which cart to return
      let cartId;
      if (req.isAuthenticated()) {
        const userCart = await storage.getCartByUserId(req.user.id);
        cartId = userCart?.id;
      } else if (req.session.id) {
        const sessionCart = await storage.getCartBySessionId(req.session.id);
        cartId = sessionCart?.id;
      }

      if (cartId) {
        const updatedCart = await storage.getCartWithItems(cartId);
        res.json(updatedCart);
      } else {
        res.status(404).json({ message: "Cart not found" });
      }

    } catch (error) {
      console.error("Error removing cart item:", error);
      res.status(500).json({ message: "Failed to remove cart item" });
    }
  });

  // Orders routes
  app.get(`${apiPrefix}/orders`, async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    try {
      const orders = await storage.getOrdersByUserId(req.user.id);
      res.json(orders);
    } catch (error) {
      console.error("Error fetching orders:", error);
      res.status(500).json({ message: "Failed to fetch orders" });
    }
  });

  app.get(`${apiPrefix}/orders/:id`, async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    try {
      const order = await storage.getOrderById(parseInt(req.params.id));
      
      // Check if order belongs to the current user
      if (order.userId !== req.user.id) {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      res.json(order);
    } catch (error) {
      console.error(`Error fetching order ${req.params.id}:`, error);
      res.status(404).json({ message: "Order not found" });
    }
  });

  app.post(`${apiPrefix}/orders`, async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    try {
      const { 
        shippingAddress, 
        shippingCity, 
        shippingZipCode, 
        shippingCountry, 
        paymentMethod, 
        total,
        shippingCost,
        items 
      } = req.body;

      // Create order
      const order = await storage.createOrder({
        userId: req.user.id,
        status: "pending",
        total,
        shippingCost,
        shippingAddress,
        shippingCity,
        shippingZipCode,
        shippingCountry,
        paymentMethod
      });

      // Add order items
      for (const item of items) {
        await db.insert(orderItems).values({
          orderId: order.id,
          productId: item.productId,
          variantId: item.variantId,
          quantity: item.quantity,
          price: item.price
        });
      }

      // Clear the user's cart
      const userCart = await storage.getCartByUserId(req.user.id);
      if (userCart) {
        // Delete all cart items
        await db.delete(cartItems).where(eq(cartItems.cartId, userCart.id));
      }

      // Return the complete order
      const completeOrder = await storage.getOrderById(order.id);
      res.status(201).json(completeOrder);

    } catch (error) {
      console.error("Error creating order:", error);
      res.status(500).json({ message: "Failed to create order" });
    }
  });

  // Additional routes for colors and sizes
  app.get(`${apiPrefix}/colors`, async (req, res) => {
    try {
      const colors = await storage.getColors();
      res.json(colors);
    } catch (error) {
      console.error("Error fetching colors:", error);
      res.status(500).json({ message: "Failed to fetch colors" });
    }
  });

  app.get(`${apiPrefix}/sizes`, async (req, res) => {
    try {
      const { categoryType } = req.query;
      const sizes = await storage.getSizes(categoryType as string | undefined);
      res.json(sizes);
    } catch (error) {
      console.error("Error fetching sizes:", error);
      res.status(500).json({ message: "Failed to fetch sizes" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
