import { db } from "@db";
import { 
  users, 
  products, 
  categories, 
  orders, 
  orderItems, 
  carts, 
  cartItems, 
  productVariants, 
  colors, 
  sizes,
  InsertUser,
  User
} from "@shared/schema";
import { eq, and, desc, asc, like, inArray, sql } from "drizzle-orm";
import session from "express-session";
import connectPg from "connect-pg-simple";
import { pool } from "@db";

const PostgresSessionStore = connectPg(session);

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<User>): Promise<User>;
  deleteUser(id: number): Promise<void>;

  // Product methods
  getProducts(options?: {
    categoryType?: string;
    categoryId?: number;
    isNew?: boolean;
    isFeatured?: boolean;
    limit?: number;
    offset?: number;
    sortBy?: string;
    search?: string;
    minPrice?: number;
    maxPrice?: number;
  }): Promise<any[]>;
  getProductById(id: number): Promise<any>;
  getProductBySlug(slug: string): Promise<any>;
  getCategoryProducts(categoryId: number): Promise<any[]>;

  // Category methods
  getCategories(): Promise<any[]>;
  getCategoryById(id: number): Promise<any>;
  getCategoryBySlug(slug: string): Promise<any>;

  // Cart methods
  getCartByUserId(userId: number): Promise<any>;
  getCartBySessionId(sessionId: string): Promise<any>;
  createCart(data: { userId?: number; sessionId?: string }): Promise<any>;
  addItemToCart(cartId: number, data: { productId: number; variantId?: number; quantity: number }): Promise<any>;
  updateCartItem(cartItemId: number, quantity: number): Promise<any>;
  removeCartItem(cartItemId: number): Promise<void>;
  getCartWithItems(cartId: number): Promise<any>;

  // Order methods
  getOrdersByUserId(userId: number): Promise<any[]>;
  getOrderById(id: number): Promise<any>;
  createOrder(data: any): Promise<any>;
  updateOrder(id: number, data: any): Promise<any>;

  // Variant related methods
  getProductVariants(productId: number): Promise<any[]>;
  getColors(): Promise<any[]>;
  getSizes(categoryType?: string): Promise<any[]>;

  sessionStore: session.SessionStore;
}

export class DatabaseStorage implements IStorage {
  sessionStore: session.SessionStore;

  constructor() {
    this.sessionStore = new PostgresSessionStore({
      pool,
      createTableIfMissing: true
    });
  }

  // User methods
  async getUser(id: number): Promise<User> {
    const result = await db.query.users.findFirst({
      where: eq(users.id, id)
    });
    
    if (!result) {
      throw new Error(`User with id ${id} not found`);
    }
    
    return result;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return await db.query.users.findFirst({
      where: eq(users.username, username)
    });
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return await db.query.users.findFirst({
      where: eq(users.email, email)
    });
  }

  async createUser(user: InsertUser): Promise<User> {
    const result = await db.insert(users).values(user).returning();
    return result[0];
  }

  async updateUser(id: number, userData: Partial<User>): Promise<User> {
    const result = await db
      .update(users)
      .set(userData)
      .where(eq(users.id, id))
      .returning();
    
    return result[0];
  }

  async deleteUser(id: number): Promise<void> {
    await db.delete(users).where(eq(users.id, id));
  }

  // Product methods
  async getProducts(options: {
    categoryType?: string;
    categoryId?: number;
    isNew?: boolean;
    isFeatured?: boolean;
    limit?: number;
    offset?: number;
    sortBy?: string;
    search?: string;
    minPrice?: number;
    maxPrice?: number;
  } = {}): Promise<any[]> {
    let query = db.select().from(products);

    // Apply filters
    if (options.categoryType) {
      query = query.where(eq(products.categoryType, options.categoryType));
    }

    if (options.categoryId) {
      query = query.where(eq(products.categoryId, options.categoryId));
    }

    if (options.isNew !== undefined) {
      query = query.where(eq(products.isNew, options.isNew));
    }

    if (options.isFeatured !== undefined) {
      query = query.where(eq(products.isFeatured, options.isFeatured));
    }

    if (options.search) {
      query = query.where(like(products.name, `%${options.search}%`));
    }

    if (options.minPrice !== undefined) {
      query = query.where(sql`${products.price} >= ${options.minPrice}`);
    }

    if (options.maxPrice !== undefined) {
      query = query.where(sql`${products.price} <= ${options.maxPrice}`);
    }

    // Apply sorting
    if (options.sortBy) {
      switch (options.sortBy) {
        case 'priceAsc':
          query = query.orderBy(asc(products.price));
          break;
        case 'priceDesc':
          query = query.orderBy(desc(products.price));
          break;
        case 'newest':
          query = query.orderBy(desc(products.createdAt));
          break;
        case 'nameAsc':
          query = query.orderBy(asc(products.name));
          break;
        case 'nameDesc':
          query = query.orderBy(desc(products.name));
          break;
        default:
          query = query.orderBy(desc(products.createdAt));
      }
    } else {
      query = query.orderBy(desc(products.createdAt));
    }

    // Apply pagination
    if (options.limit) {
      query = query.limit(options.limit);
    }

    if (options.offset) {
      query = query.offset(options.offset);
    }

    const result = await query;
    return result;
  }

  async getProductById(id: number): Promise<any> {
    const result = await db.query.products.findFirst({
      where: eq(products.id, id),
      with: {
        category: true,
        productVariants: {
          with: {
            color: true,
            size: true
          }
        }
      }
    });

    if (!result) {
      throw new Error(`Product with id ${id} not found`);
    }

    return result;
  }

  async getProductBySlug(slug: string): Promise<any> {
    const result = await db.query.products.findFirst({
      where: eq(products.slug, slug),
      with: {
        category: true,
        productVariants: {
          with: {
            color: true,
            size: true
          }
        }
      }
    });

    if (!result) {
      throw new Error(`Product with slug ${slug} not found`);
    }

    return result;
  }

  async getCategoryProducts(categoryId: number): Promise<any[]> {
    return await db.query.products.findMany({
      where: eq(products.categoryId, categoryId),
      with: {
        productVariants: {
          with: {
            color: true,
            size: true
          }
        }
      }
    });
  }

  // Category methods
  async getCategories(): Promise<any[]> {
    return await db.query.categories.findMany();
  }

  async getCategoryById(id: number): Promise<any> {
    const result = await db.query.categories.findFirst({
      where: eq(categories.id, id),
      with: {
        products: true
      }
    });

    if (!result) {
      throw new Error(`Category with id ${id} not found`);
    }

    return result;
  }

  async getCategoryBySlug(slug: string): Promise<any> {
    const result = await db.query.categories.findFirst({
      where: eq(categories.slug, slug),
      with: {
        products: true
      }
    });

    if (!result) {
      throw new Error(`Category with slug ${slug} not found`);
    }

    return result;
  }

  // Cart methods
  async getCartByUserId(userId: number): Promise<any> {
    return await db.query.carts.findFirst({
      where: eq(carts.userId, userId),
      with: {
        cartItems: {
          with: {
            product: true,
            variant: {
              with: {
                color: true,
                size: true
              }
            }
          }
        }
      }
    });
  }

  async getCartBySessionId(sessionId: string): Promise<any> {
    return await db.query.carts.findFirst({
      where: eq(carts.sessionId, sessionId),
      with: {
        cartItems: {
          with: {
            product: true,
            variant: {
              with: {
                color: true,
                size: true
              }
            }
          }
        }
      }
    });
  }

  async createCart(data: { userId?: number; sessionId?: string }): Promise<any> {
    const result = await db.insert(carts).values(data).returning();
    return result[0];
  }

  async addItemToCart(cartId: number, data: { productId: number; variantId?: number; quantity: number }): Promise<any> {
    // Check if item already exists in cart
    const existingItem = await db.query.cartItems.findFirst({
      where: and(
        eq(cartItems.cartId, cartId),
        eq(cartItems.productId, data.productId),
        data.variantId ? eq(cartItems.variantId, data.variantId) : undefined
      )
    });

    if (existingItem) {
      // Update quantity if item exists
      const result = await db
        .update(cartItems)
        .set({ quantity: existingItem.quantity + data.quantity })
        .where(eq(cartItems.id, existingItem.id))
        .returning();
      return result[0];
    } else {
      // Insert new item
      const result = await db
        .insert(cartItems)
        .values({ cartId, ...data })
        .returning();
      return result[0];
    }
  }

  async updateCartItem(cartItemId: number, quantity: number): Promise<any> {
    const result = await db
      .update(cartItems)
      .set({ quantity })
      .where(eq(cartItems.id, cartItemId))
      .returning();
    return result[0];
  }

  async removeCartItem(cartItemId: number): Promise<void> {
    await db.delete(cartItems).where(eq(cartItems.id, cartItemId));
  }

  async getCartWithItems(cartId: number): Promise<any> {
    return await db.query.carts.findFirst({
      where: eq(carts.id, cartId),
      with: {
        cartItems: {
          with: {
            product: true,
            variant: {
              with: {
                color: true,
                size: true
              }
            }
          }
        }
      }
    });
  }

  // Order methods
  async getOrdersByUserId(userId: number): Promise<any[]> {
    return await db.query.orders.findMany({
      where: eq(orders.userId, userId),
      orderBy: [desc(orders.createdAt)]
    });
  }

  async getOrderById(id: number): Promise<any> {
    const result = await db.query.orders.findFirst({
      where: eq(orders.id, id),
      with: {
        orderItems: {
          with: {
            product: true,
            variant: {
              with: {
                color: true,
                size: true
              }
            }
          }
        }
      }
    });

    if (!result) {
      throw new Error(`Order with id ${id} not found`);
    }

    return result;
  }

  async createOrder(data: any): Promise<any> {
    const result = await db.insert(orders).values(data).returning();
    return result[0];
  }

  async updateOrder(id: number, data: any): Promise<any> {
    const result = await db
      .update(orders)
      .set(data)
      .where(eq(orders.id, id))
      .returning();
    return result[0];
  }

  // Variant related methods
  async getProductVariants(productId: number): Promise<any[]> {
    return await db.query.productVariants.findMany({
      where: eq(productVariants.productId, productId),
      with: {
        color: true,
        size: true
      }
    });
  }

  async getColors(): Promise<any[]> {
    return await db.query.colors.findMany();
  }

  async getSizes(categoryType?: string): Promise<any[]> {
    if (categoryType) {
      return await db.query.sizes.findMany({
        where: eq(sizes.categoryType, categoryType)
      });
    }
    return await db.query.sizes.findMany();
  }
}

export const storage = new DatabaseStorage();
