import { createContext, ReactNode, useContext, useEffect, useState } from "react";
import { apiRequest, queryClient } from "./queryClient";
import { useToast } from "@/hooks/use-toast";

interface CartItem {
  id: number;
  productId: number;
  variantId?: number;
  quantity: number;
  product: {
    id: number;
    name: string;
    price: number;
    imageUrl: string;
  };
  variant?: {
    id: number;
    size?: {
      id: number;
      name: string;
    };
    color?: {
      id: number;
      name: string;
      value: string;
    };
  };
}

interface Cart {
  id: number;
  userId?: number;
  sessionId?: string;
  cartItems: CartItem[];
}

interface CartContextType {
  cart: Cart | null;
  loading: boolean;
  error: Error | null;
  addToCart: (productId: number, quantity: number, variantId?: number) => Promise<void>;
  updateCartItem: (cartItemId: number, quantity: number) => Promise<void>;
  removeCartItem: (cartItemId: number) => Promise<void>;
  clearCart: () => void;
  totalItems: number;
}

const CartContext = createContext<CartContextType | null>(null);

export function CartProvider({ children }: { children: ReactNode }) {
  const { toast } = useToast();
  const [cart, setCart] = useState<Cart | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<Error | null>(null);

  const fetchCart = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/cart', {
        credentials: 'include'
      });
      
      if (response.ok) {
        const cartData = await response.json();
        setCart(cartData);
      } else {
        console.error('Failed to fetch cart:', response.statusText);
      }
    } catch (err) {
      setError(err instanceof Error ? err : new Error('Failed to fetch cart'));
      console.error('Error fetching cart:', err);
    } finally {
      setLoading(false);
    }
  };

  // Initial cart fetch
  useEffect(() => {
    fetchCart();
  }, []);

  const addToCart = async (productId: number, quantity: number, variantId?: number) => {
    setLoading(true);
    try {
      const response = await apiRequest('POST', '/api/cart/items', {
        productId,
        quantity,
        variantId
      });
      
      const updatedCart = await response.json();
      setCart(updatedCart);
      
      toast({
        title: "Товар добавлен в корзину",
        description: `${quantity} шт. добавлено в корзину`,
      });
      
      // Invalidate cart queries if needed
      queryClient.invalidateQueries({ queryKey: ['/api/cart'] });
    } catch (err) {
      const error = err instanceof Error ? err : new Error('Failed to add item to cart');
      setError(error);
      
      toast({
        title: "Ошибка",
        description: error.message,
        variant: "destructive",
      });
      
      console.error('Error adding to cart:', err);
    } finally {
      setLoading(false);
    }
  };

  const updateCartItem = async (cartItemId: number, quantity: number) => {
    setLoading(true);
    try {
      const response = await apiRequest('PUT', `/api/cart/items/${cartItemId}`, {
        quantity
      });
      
      const updatedCart = await response.json();
      setCart(updatedCart);
      
      // Invalidate cart queries if needed
      queryClient.invalidateQueries({ queryKey: ['/api/cart'] });
    } catch (err) {
      const error = err instanceof Error ? err : new Error('Failed to update cart item');
      setError(error);
      
      toast({
        title: "Ошибка",
        description: error.message,
        variant: "destructive",
      });
      
      console.error('Error updating cart item:', err);
    } finally {
      setLoading(false);
    }
  };

  const removeCartItem = async (cartItemId: number) => {
    setLoading(true);
    try {
      const response = await apiRequest('DELETE', `/api/cart/items/${cartItemId}`);
      
      const updatedCart = await response.json();
      setCart(updatedCart);
      
      toast({
        title: "Товар удален",
        description: "Товар успешно удален из корзины",
      });
      
      // Invalidate cart queries if needed
      queryClient.invalidateQueries({ queryKey: ['/api/cart'] });
    } catch (err) {
      const error = err instanceof Error ? err : new Error('Failed to remove cart item');
      setError(error);
      
      toast({
        title: "Ошибка",
        description: error.message,
        variant: "destructive",
      });
      
      console.error('Error removing cart item:', err);
    } finally {
      setLoading(false);
    }
  };

  const clearCart = () => {
    if (cart && cart.cartItems) {
      Promise.all(
        cart.cartItems.map(item => removeCartItem(item.id))
      ).then(() => {
        toast({
          title: "Корзина очищена",
          description: "Все товары удалены из корзины",
        });
      });
    }
  };

  // Calculate total items
  const totalItems = cart?.cartItems?.reduce((total, item) => total + item.quantity, 0) || 0;

  return (
    <CartContext.Provider
      value={{
        cart,
        loading,
        error,
        addToCart,
        updateCartItem,
        removeCartItem,
        clearCart,
        totalItems
      }}
    >
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error("useCart must be used within a CartProvider");
  }
  return context;
}
