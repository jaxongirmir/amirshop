import { useEffect } from "react";
import { Link } from "wouter";
import { X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { CartItem } from "@/components/ui/cart-item";
import { useCart } from "@/lib/cart-context";
import { formatCurrency } from "@/lib/utils";

interface MiniCartProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function MiniCart({ isOpen, onClose }: MiniCartProps) {
  const { cart, loading } = useCart();
  
  // Calculate totals
  const subtotal = cart?.cartItems?.reduce((total, item) => {
    return total + (item.product.price * item.quantity);
  }, 0) || 0;
  
  const shippingCost = subtotal > 0 ? 350 : 0;
  const total = subtotal + shippingCost;

  // Handle escape key for closing cart
  useEffect(() => {
    const handleEscKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };

    // Handle body scroll lock
    if (isOpen) {
      document.body.style.overflow = 'hidden';
      window.addEventListener('keydown', handleEscKey);
    } else {
      document.body.style.overflow = '';
    }

    return () => {
      document.body.style.overflow = '';
      window.removeEventListener('keydown', handleEscKey);
    };
  }, [isOpen, onClose]);

  return (
    <div 
      className={`mini-cart fixed top-0 right-0 h-full bg-white w-full md:w-96 shadow-xl z-50 ${isOpen ? 'show' : ''}`}
      style={{ display: isOpen ? 'block' : 'none' }}
    >
      <div className="flex flex-col h-full">
        <div className="p-4 border-b flex justify-between items-center">
          <h3 className="text-lg font-bold">
            Корзина {cart?.cartItems?.length > 0 && (
              <span className="text-primary">({cart.cartItems.length})</span>
            )}
          </h3>
          <button className="text-2xl" onClick={onClose}>
            <X className="h-6 w-6" />
          </button>
        </div>
        
        <div className="flex-grow overflow-y-auto p-4 space-y-4">
          {loading ? (
            <div className="flex justify-center items-center h-40">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
            </div>
          ) : cart?.cartItems?.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-40">
              <div className="text-gray-500 mb-4">
                <i className="fas fa-shopping-bag text-4xl"></i>
              </div>
              <p className="text-lg text-gray-600">Ваша корзина пуста</p>
              <Button
                variant="link"
                className="mt-2 text-primary"
                onClick={onClose}
              >
                Продолжить покупки
              </Button>
            </div>
          ) : (
            <>
              {cart?.cartItems?.map((item) => (
                <CartItem
                  key={item.id}
                  id={item.id}
                  name={item.product.name}
                  price={item.product.price}
                  quantity={item.quantity}
                  imageUrl={item.product.imageUrl}
                  size={item.variant?.size?.name}
                  color={item.variant?.color?.name}
                  variantId={item.variantId}
                />
              ))}
            </>
          )}
        </div>
        
        {cart?.cartItems?.length > 0 && (
          <div className="p-4 border-t">
            <div className="mb-4 space-y-2">
              <div className="flex justify-between">
                <span>Подытог:</span>
                <span className="font-medium">{formatCurrency(subtotal)}</span>
              </div>
              <div className="flex justify-between">
                <span>Доставка:</span>
                <span className="font-medium">{formatCurrency(shippingCost)}</span>
              </div>
              <div className="flex justify-between font-bold text-lg pt-2 border-t">
                <span>Итого:</span>
                <span>{formatCurrency(total)}</span>
              </div>
            </div>
            
            <Link href="/checkout">
              <Button className="w-full py-3 mb-3" onClick={onClose}>
                Оформить заказ
              </Button>
            </Link>
            
            <Button 
              variant="outline" 
              className="w-full py-3 border border-primary text-primary hover:bg-blue-50"
              onClick={onClose}
            >
              Продолжить покупки
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
