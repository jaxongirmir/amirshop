import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Search, User, ShoppingBag, Heart, Menu, X } from "lucide-react";
import MiniCart from "./mini-cart";
import MobileMenu from "./mobile-menu";
import { useCart } from "@/lib/cart-context";
import { useQuery } from "@tanstack/react-query";

export default function Header() {
  const [location] = useLocation();
  const { user, logoutMutation } = useAuth();
  const { totalItems } = useCart();
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isMobileSearchOpen, setIsMobileSearchOpen] = useState(false);
  const [isAccountDropdownOpen, setIsAccountDropdownOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");

  // Fetch categories for the navigation
  const { data: categories } = useQuery({
    queryKey: ["/api/categories"],
  });

  // Close dropdowns when clicking outside
  useEffect(() => {
    const handleClickOutside = () => {
      setIsAccountDropdownOpen(false);
    };

    document.addEventListener("click", handleClickOutside);
    return () => document.removeEventListener("click", handleClickOutside);
  }, []);

  const handleToggleAccount = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsAccountDropdownOpen(!isAccountDropdownOpen);
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      window.location.href = `/products?search=${encodeURIComponent(searchQuery)}`;
    }
  };

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  const womenCategory = categories?.find((cat: any) => cat.slug === "women");
  const menCategory = categories?.find((cat: any) => cat.slug === "men");
  const childrenCategory = categories?.find((cat: any) => cat.slug === "children");

  return (
    <header className="bg-white shadow-sm sticky top-0 z-50">
      {/* Top bar with contact & account info */}
      <div className="bg-dark text-white text-xs py-2">
        <div className="container mx-auto px-4 flex justify-between items-center">
          <div className="flex items-center space-x-4">
            <span><i className="fas fa-phone-alt mr-1"></i> +7 (495) 123-45-67</span>
            <span className="hidden md:inline"><i className="fas fa-envelope mr-1"></i> info@fashionhub.ru</span>
          </div>
          <div className="flex items-center space-x-4">
            <Link href="/shipping" className="hover:text-gray-300 transition">Доставка</Link>
            <Link href="/payment" className="hover:text-gray-300 transition">Оплата</Link>
            <Link href="/contacts" className="hover:text-gray-300 transition">Контакты</Link>
          </div>
        </div>
      </div>
      
      {/* Main header with logo, search, cart */}
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <Link href="/" className="text-3xl font-bold font-montserrat text-dark flex-shrink-0">
            <span className="text-primary">Fashion</span>Hub
          </Link>
          
          {/* Search bar */}
          <form 
            className="hidden md:flex flex-grow mx-8 relative"
            onSubmit={handleSearch}
          >
            <input 
              type="text" 
              placeholder="Поиск товаров..." 
              className="w-full py-2 px-4 border border-gray-deep rounded-l-md focus:outline-none focus:ring-2 focus:ring-primary"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
            <button 
              type="submit"
              className="bg-primary text-white px-5 py-2 rounded-r-md hover:bg-blue-600 transition"
            >
              <Search className="h-5 w-5" />
            </button>
          </form>
          
          {/* User actions */}
          <div className="flex items-center space-x-4">
            <button 
              className="md:hidden relative"
              onClick={() => setIsMobileSearchOpen(!isMobileSearchOpen)}
            >
              <Search className="h-5 w-5" />
            </button>
            
            <Link href="/wishlist" className="hidden md:flex items-center hover:text-primary transition">
              <Heart className="h-5 w-5" />
              <span className="ml-1 hidden lg:inline">Избранное</span>
            </Link>
            
            <div className="relative">
              <button 
                className="flex items-center hover:text-primary transition"
                onClick={handleToggleAccount}
              >
                <User className="h-5 w-5" />
                <span className="ml-1 hidden lg:inline">Аккаунт</span>
                <i className="fas fa-chevron-down text-xs ml-1 hidden lg:inline"></i>
              </button>
              
              {isAccountDropdownOpen && (
                <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-2 z-10">
                  {user ? (
                    <>
                      <span className="block px-4 py-2 text-sm text-gray-500">Привет, {user.username}</span>
                      <div className="border-t border-gray-deep my-1"></div>
                      <Link href="/account" className="block px-4 py-2 text-sm hover:bg-gray-100 transition">
                        Личный кабинет
                      </Link>
                      <Link href="/orders" className="block px-4 py-2 text-sm hover:bg-gray-100 transition">
                        Мои заказы
                      </Link>
                      <div className="border-t border-gray-deep my-1"></div>
                      <button 
                        onClick={handleLogout}
                        className="block w-full text-left px-4 py-2 text-sm hover:bg-gray-100 transition"
                      >
                        Выход
                      </button>
                    </>
                  ) : (
                    <>
                      <Link href="/auth" className="block px-4 py-2 text-sm hover:bg-gray-100 transition">
                        Вход
                      </Link>
                      <Link href="/auth" className="block px-4 py-2 text-sm hover:bg-gray-100 transition">
                        Регистрация
                      </Link>
                    </>
                  )}
                </div>
              )}
            </div>
            
            <button 
              className="relative flex items-center hover:text-primary transition"
              onClick={() => setIsCartOpen(true)}
            >
              <ShoppingBag className="h-5 w-5" />
              <span className="ml-1 hidden lg:inline">Корзина</span>
              {totalItems > 0 && (
                <span className="absolute -top-2 -right-2 bg-secondary text-white text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center">
                  {totalItems}
                </span>
              )}
            </button>
          </div>
        </div>
        
        {/* Mobile search */}
        {isMobileSearchOpen && (
          <form 
            className="mt-4 relative"
            onSubmit={handleSearch}
          >
            <input 
              type="text" 
              placeholder="Поиск товаров..." 
              className="w-full py-2 px-4 border border-gray-deep rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
            <button 
              type="submit"
              className="absolute right-0 top-0 h-full px-4 text-gray-500"
            >
              <Search className="h-5 w-5" />
            </button>
          </form>
        )}
      </div>
      
      {/* Main navigation */}
      <nav className="border-t border-gray-deep bg-white">
        <div className="container mx-auto px-4">
          <div className="hidden md:flex items-center justify-between">
            <div className="flex space-x-1 py-3 text-sm font-medium">
              {womenCategory && (
                <div className="relative dropdown group">
                  <Link href={`/products/category/${womenCategory.slug}`} className="px-4 py-2 hover:text-primary transition flex items-center">
                    <span>Женщинам</span>
                    <i className="fas fa-chevron-down text-xs ml-1"></i>
                  </Link>
                  <div className="absolute left-0 mt-1 w-64 bg-white rounded-md shadow-lg py-2 z-10 hidden dropdown-menu">
                    <div className="grid grid-cols-2 gap-2 p-3">
                      {womenCategory.subcategories?.map((subcat: any) => (
                        <Link 
                          key={subcat.id}
                          href={`/products/category/${subcat.slug}`} 
                          className="block px-2 py-1 text-sm hover:text-primary transition"
                        >
                          {subcat.name}
                        </Link>
                      ))}
                    </div>
                  </div>
                </div>
              )}
              
              {menCategory && (
                <div className="relative dropdown group">
                  <Link href={`/products/category/${menCategory.slug}`} className="px-4 py-2 hover:text-primary transition flex items-center">
                    <span>Мужчинам</span>
                    <i className="fas fa-chevron-down text-xs ml-1"></i>
                  </Link>
                  <div className="absolute left-0 mt-1 w-64 bg-white rounded-md shadow-lg py-2 z-10 hidden dropdown-menu">
                    <div className="grid grid-cols-2 gap-2 p-3">
                      {menCategory.subcategories?.map((subcat: any) => (
                        <Link 
                          key={subcat.id}
                          href={`/products/category/${subcat.slug}`} 
                          className="block px-2 py-1 text-sm hover:text-primary transition"
                        >
                          {subcat.name}
                        </Link>
                      ))}
                    </div>
                  </div>
                </div>
              )}
              
              {childrenCategory && (
                <div className="relative dropdown group">
                  <Link href={`/products/category/${childrenCategory.slug}`} className="px-4 py-2 hover:text-primary transition flex items-center">
                    <span>Детям</span>
                    <i className="fas fa-chevron-down text-xs ml-1"></i>
                  </Link>
                  <div className="absolute left-0 mt-1 w-64 bg-white rounded-md shadow-lg py-2 z-10 hidden dropdown-menu">
                    <div className="grid grid-cols-2 gap-2 p-3">
                      {childrenCategory.subcategories?.map((subcat: any) => (
                        <Link 
                          key={subcat.id}
                          href={`/products/category/${subcat.slug}`} 
                          className="block px-2 py-1 text-sm hover:text-primary transition"
                        >
                          {subcat.name}
                        </Link>
                      ))}
                    </div>
                  </div>
                </div>
              )}
              
              <Link href="/products/category/accessories" className="px-4 py-2 hover:text-primary transition">Аксессуары</Link>
              <Link href="/products" className="px-4 py-2 text-secondary font-semibold transition">SALE</Link>
              <Link href="/products?isNew=true" className="px-4 py-2 hover:text-primary transition">Новинки</Link>
            </div>
            
            <Link href="/premium" className="text-accent flex items-center font-medium text-sm">
              <i className="fas fa-medal mr-1"></i>
              <span>Premium</span>
            </Link>
          </div>
          
          {/* Mobile menu toggle */}
          <div className="flex md:hidden items-center justify-between py-3">
            <button 
              className="text-dark hover:text-primary"
              onClick={() => setIsMobileMenuOpen(true)}
            >
              <Menu className="h-6 w-6" />
            </button>
            <Link href="/premium" className="text-accent flex items-center font-medium text-sm">
              <i className="fas fa-medal mr-1"></i>
              <span>Premium</span>
            </Link>
          </div>
        </div>
      </nav>
      
      {/* Mini cart */}
      <MiniCart 
        isOpen={isCartOpen} 
        onClose={() => setIsCartOpen(false)} 
      />
      
      {/* Mobile menu */}
      <MobileMenu 
        isOpen={isMobileMenuOpen} 
        onClose={() => setIsMobileMenuOpen(false)} 
        categories={categories || []}
      />
    </header>
  );
}
