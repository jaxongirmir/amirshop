import { Link } from "wouter";

export default function Footer() {
  return (
    <footer className="bg-dark-light text-white pt-12 pb-6">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company Info */}
          <div>
            <h3 className="text-xl font-bold mb-4 font-montserrat">FashionHub</h3>
            <p className="text-white/70 mb-4">
              Интернет-магазин стильной одежды для женщин, мужчин и детей. 
              Новые коллекции и тренды каждый сезон.
            </p>
            <div className="flex space-x-4 mt-4">
              <a href="#" className="text-white/70 hover:text-primary transition">
                <i className="fab fa-facebook-f"></i>
              </a>
              <a href="#" className="text-white/70 hover:text-primary transition">
                <i className="fab fa-instagram"></i>
              </a>
              <a href="#" className="text-white/70 hover:text-primary transition">
                <i className="fab fa-twitter"></i>
              </a>
              <a href="#" className="text-white/70 hover:text-primary transition">
                <i className="fab fa-youtube"></i>
              </a>
            </div>
          </div>
          
          {/* Shop Links */}
          <div>
            <h3 className="text-lg font-bold mb-4">Магазин</h3>
            <ul className="space-y-2">
              <li><Link href="/products/category/women" className="text-white/70 hover:text-white transition">Женщинам</Link></li>
              <li><Link href="/products/category/men" className="text-white/70 hover:text-white transition">Мужчинам</Link></li>
              <li><Link href="/products/category/children" className="text-white/70 hover:text-white transition">Детям</Link></li>
              <li><Link href="/products/category/shoes" className="text-white/70 hover:text-white transition">Обувь</Link></li>
              <li><Link href="/products/category/accessories" className="text-white/70 hover:text-white transition">Аксессуары</Link></li>
              <li><Link href="/products?isNew=true" className="text-white/70 hover:text-white transition">Новинки</Link></li>
              <li><Link href="/products" className="text-white/70 hover:text-white transition">Распродажа</Link></li>
            </ul>
          </div>
          
          {/* Help Links */}
          <div>
            <h3 className="text-lg font-bold mb-4">Помощь</h3>
            <ul className="space-y-2">
              <li><Link href="/contacts" className="text-white/70 hover:text-white transition">Контакты</Link></li>
              <li><Link href="/shipping" className="text-white/70 hover:text-white transition">Доставка и оплата</Link></li>
              <li><Link href="/returns" className="text-white/70 hover:text-white transition">Возврат и обмен</Link></li>
              <li><Link href="/sizes" className="text-white/70 hover:text-white transition">Таблица размеров</Link></li>
              <li><Link href="/track-order" className="text-white/70 hover:text-white transition">Отследить заказ</Link></li>
              <li><Link href="/loyalty" className="text-white/70 hover:text-white transition">Программа лояльности</Link></li>
              <li><Link href="/gift-cards" className="text-white/70 hover:text-white transition">Подарочные карты</Link></li>
            </ul>
          </div>
          
          {/* Contact Info */}
          <div>
            <h3 className="text-lg font-bold mb-4">Контакты</h3>
            <ul className="space-y-3">
              <li className="flex items-start">
                <i className="fas fa-map-marker-alt mt-1 mr-2 text-primary"></i>
                <span className="text-white/70">г. Москва, ул. Модная, 123</span>
              </li>
              <li className="flex items-center">
                <i className="fas fa-phone-alt mr-2 text-primary"></i>
                <span className="text-white/70">+7 (495) 123-45-67</span>
              </li>
              <li className="flex items-center">
                <i className="fas fa-envelope mr-2 text-primary"></i>
                <span className="text-white/70">info@fashionhub.ru</span>
              </li>
              <li className="flex items-center">
                <i className="fas fa-clock mr-2 text-primary"></i>
                <span className="text-white/70">Пн-Вс: 9:00 – 21:00</span>
              </li>
            </ul>
            
            <div className="mt-6">
              <h4 className="font-medium mb-2">Способы оплаты</h4>
              <div className="flex gap-2">
                <span className="bg-white/10 p-1 rounded"><i className="fab fa-cc-visa text-xl"></i></span>
                <span className="bg-white/10 p-1 rounded"><i className="fab fa-cc-mastercard text-xl"></i></span>
                <span className="bg-white/10 p-1 rounded"><i className="fab fa-cc-apple-pay text-xl"></i></span>
                <span className="bg-white/10 p-1 rounded"><i className="fab fa-google-pay text-xl"></i></span>
              </div>
            </div>
          </div>
        </div>
        
        <div className="border-t border-gray-700 mt-10 pt-6 flex flex-col md:flex-row justify-between items-center">
          <p className="text-white/60 text-sm">© {new Date().getFullYear()} FashionHub. Все права защищены.</p>
          
          <div className="flex space-x-4 mt-4 md:mt-0 text-sm">
            <Link href="/privacy" className="text-white/60 hover:text-white transition">Политика конфиденциальности</Link>
            <Link href="/terms" className="text-white/60 hover:text-white transition">Условия использования</Link>
          </div>
        </div>
      </div>
      
      {/* Back to top button */}
      <button 
        className="fixed bottom-6 right-6 bg-primary text-white w-10 h-10 rounded-full flex items-center justify-center shadow-lg hover:bg-blue-600"
        onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
      >
        <i className="fas fa-chevron-up"></i>
      </button>
    </footer>
  );
}
