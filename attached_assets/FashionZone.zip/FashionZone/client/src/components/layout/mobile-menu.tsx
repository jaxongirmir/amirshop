import { useState } from "react";
import { Link } from "wouter";
import { X } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";

interface MobileMenuProps {
  isOpen: boolean;
  onClose: () => void;
  categories: any[];
}

export default function MobileMenu({ isOpen, onClose, categories }: MobileMenuProps) {
  const { user, logoutMutation } = useAuth();
  
  // State for expanded subcategories
  const [expandedCategories, setExpandedCategories] = useState<Record<string, boolean>>({});

  const toggleCategory = (categoryId: number) => {
    setExpandedCategories(prev => ({
      ...prev,
      [categoryId]: !prev[categoryId]
    }));
  };

  const handleLogout = () => {
    logoutMutation.mutate();
    onClose();
  };

  // Find main categories
  const womenCategory = categories.find(cat => cat.slug === "women");
  const menCategory = categories.find(cat => cat.slug === "men");
  const childrenCategory = categories.find(cat => cat.slug === "children");

  return (
    <div className={`mobile-menu fixed inset-0 bg-white z-50 overflow-y-auto pb-20 ${isOpen ? 'show' : ''}`}>
      <div className="p-4 flex justify-between items-center border-b">
        <span className="text-xl font-bold font-montserrat">Меню</span>
        <button onClick={onClose} className="text-2xl">
          <X className="h-6 w-6" />
        </button>
      </div>
      
      <div className="p-4">
        <div className="space-y-3">
          {/* Women's category */}
          {womenCategory && (
            <div className="border-b pb-2">
              <button 
                className="flex items-center justify-between w-full py-2 font-medium"
                onClick={() => toggleCategory(womenCategory.id)}
              >
                <span>Женщинам</span>
                <i className={`fas fa-chevron-${expandedCategories[womenCategory.id] ? 'up' : 'down'}`}></i>
              </button>
              <div className={`pl-4 space-y-2 mt-2 ${expandedCategories[womenCategory.id] ? '' : 'hidden'}`}>
                {womenCategory.subcategories?.map((subcat: any) => (
                  <Link 
                    key={subcat.id}
                    href={`/products/category/${subcat.slug}`} 
                    className="block py-1"
                    onClick={onClose}
                  >
                    {subcat.name}
                  </Link>
                ))}
              </div>
            </div>
          )}
          
          {/* Men's category */}
          {menCategory && (
            <div className="border-b pb-2">
              <button 
                className="flex items-center justify-between w-full py-2 font-medium"
                onClick={() => toggleCategory(menCategory.id)}
              >
                <span>Мужчинам</span>
                <i className={`fas fa-chevron-${expandedCategories[menCategory.id] ? 'up' : 'down'}`}></i>
              </button>
              <div className={`pl-4 space-y-2 mt-2 ${expandedCategories[menCategory.id] ? '' : 'hidden'}`}>
                {menCategory.subcategories?.map((subcat: any) => (
                  <Link 
                    key={subcat.id}
                    href={`/products/category/${subcat.slug}`} 
                    className="block py-1"
                    onClick={onClose}
                  >
                    {subcat.name}
                  </Link>
                ))}
              </div>
            </div>
          )}
          
          {/* Children's category */}
          {childrenCategory && (
            <div className="border-b pb-2">
              <button 
                className="flex items-center justify-between w-full py-2 font-medium"
                onClick={() => toggleCategory(childrenCategory.id)}
              >
                <span>Детям</span>
                <i className={`fas fa-chevron-${expandedCategories[childrenCategory.id] ? 'up' : 'down'}`}></i>
              </button>
              <div className={`pl-4 space-y-2 mt-2 ${expandedCategories[childrenCategory.id] ? '' : 'hidden'}`}>
                {childrenCategory.subcategories?.map((subcat: any) => (
                  <Link 
                    key={subcat.id}
                    href={`/products/category/${subcat.slug}`} 
                    className="block py-1"
                    onClick={onClose}
                  >
                    {subcat.name}
                  </Link>
                ))}
              </div>
            </div>
          )}
          
          <Link href="/products/category/accessories" className="block py-2 border-b" onClick={onClose}>Аксессуары</Link>
          <Link href="/products" className="block py-2 border-b text-secondary font-semibold" onClick={onClose}>SALE</Link>
          <Link href="/products?isNew=true" className="block py-2 border-b" onClick={onClose}>Новинки</Link>
        </div>
        
        <div className="mt-6 space-y-3">
          {user ? (
            <>
              <Link href="/account" className="block py-2 flex items-center" onClick={onClose}>
                <i className="far fa-user mr-3"></i> Личный кабинет
              </Link>
              <Link href="/orders" className="block py-2 flex items-center" onClick={onClose}>
                <i className="fas fa-box mr-3"></i> Мои заказы
              </Link>
              <button 
                onClick={handleLogout} 
                className="block py-2 flex items-center w-full text-left"
              >
                <i className="fas fa-sign-out-alt mr-3"></i> Выход
              </button>
            </>
          ) : (
            <Link href="/auth" className="block py-2 flex items-center" onClick={onClose}>
              <i className="far fa-user mr-3"></i> Вход / Регистрация
            </Link>
          )}
          <Link href="/wishlist" className="block py-2 flex items-center" onClick={onClose}>
            <i className="far fa-heart mr-3"></i> Избранное
          </Link>
          <Link href="/shipping" className="block py-2 flex items-center" onClick={onClose}>
            <i className="fas fa-truck mr-3"></i> Доставка
          </Link>
          <Link href="/payment" className="block py-2 flex items-center" onClick={onClose}>
            <i className="fas fa-credit-card mr-3"></i> Оплата
          </Link>
          <Link href="/contacts" className="block py-2 flex items-center" onClick={onClose}>
            <i className="fas fa-headset mr-3"></i> Контакты
          </Link>
        </div>
      </div>
    </div>
  );
}
