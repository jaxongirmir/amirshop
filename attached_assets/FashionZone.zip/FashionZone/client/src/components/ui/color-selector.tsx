import { cn } from "@/lib/utils";

interface Color {
  id: number;
  name: string;
  value: string;
}

interface ColorSelectorProps {
  colors: Color[];
  selectedColor: string | null;
  onSelectColor: (value: string) => void;
  small?: boolean;
}

export function ColorSelector({ colors, selectedColor, onSelectColor, small = false }: ColorSelectorProps) {
  return (
    <div className="flex gap-1">
      {colors.map((color) => (
        <button
          key={color.id}
          className={cn(
            "rounded-full border border-gray-300 transition-all",
            selectedColor === color.value ? "border-2 border-primary" : "",
            small ? "w-4 h-4" : "w-6 h-6"
          )}
          style={{ backgroundColor: color.value }}
          title={color.name}
          onClick={() => onSelectColor(color.value)}
          aria-label={`Select color: ${color.name}`}
        />
      ))}
    </div>
  );
}
