import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { formatCurrency } from "@/lib/utils";

interface FiltersProps {
  categoryType?: string;
  onFilterChange: (filters: {
    minPrice?: number;
    maxPrice?: number;
    colors?: string[];
    sizes?: string[];
    sortBy?: string;
  }) => void;
}

export function Filters({ categoryType, onFilterChange }: FiltersProps) {
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 10000]);
  const [selectedColors, setSelectedColors] = useState<string[]>([]);
  const [selectedSizes, setSelectedSizes] = useState<string[]>([]);
  const [sortBy, setSortBy] = useState<string>("newest");

  // Fetch colors
  const { data: colors } = useQuery({
    queryKey: ["/api/colors"],
  });

  // Fetch sizes based on category type
  const { data: sizes } = useQuery({
    queryKey: ["/api/sizes", categoryType],
    queryFn: () => 
      fetch(`/api/sizes${categoryType ? `?categoryType=${categoryType}` : ""}`)
        .then(res => res.json())
  });

  // Apply filters when any filter changes
  useEffect(() => {
    onFilterChange({
      minPrice: priceRange[0],
      maxPrice: priceRange[1],
      colors: selectedColors.length > 0 ? selectedColors : undefined,
      sizes: selectedSizes.length > 0 ? selectedSizes : undefined,
      sortBy
    });
  }, [priceRange, selectedColors, selectedSizes, sortBy, onFilterChange]);

  const handleColorToggle = (colorId: string) => {
    setSelectedColors(prev => 
      prev.includes(colorId)
        ? prev.filter(id => id !== colorId)
        : [...prev, colorId]
    );
  };

  const handleSizeToggle = (sizeId: string) => {
    setSelectedSizes(prev => 
      prev.includes(sizeId)
        ? prev.filter(id => id !== sizeId)
        : [...prev, sizeId]
    );
  };

  return (
    <div className="space-y-6">
      {/* Sort by */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-lg">Сортировка</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <div className="flex items-center">
              <input
                type="radio"
                id="sort-newest"
                name="sortBy"
                value="newest"
                checked={sortBy === "newest"}
                onChange={() => setSortBy("newest")}
                className="mr-2"
              />
              <Label htmlFor="sort-newest">Новинки</Label>
            </div>
            <div className="flex items-center">
              <input
                type="radio"
                id="sort-priceAsc"
                name="sortBy"
                value="priceAsc"
                checked={sortBy === "priceAsc"}
                onChange={() => setSortBy("priceAsc")}
                className="mr-2"
              />
              <Label htmlFor="sort-priceAsc">Цена: по возрастанию</Label>
            </div>
            <div className="flex items-center">
              <input
                type="radio"
                id="sort-priceDesc"
                name="sortBy"
                value="priceDesc"
                checked={sortBy === "priceDesc"}
                onChange={() => setSortBy("priceDesc")}
                className="mr-2"
              />
              <Label htmlFor="sort-priceDesc">Цена: по убыванию</Label>
            </div>
            <div className="flex items-center">
              <input
                type="radio"
                id="sort-nameAsc"
                name="sortBy"
                value="nameAsc"
                checked={sortBy === "nameAsc"}
                onChange={() => setSortBy("nameAsc")}
                className="mr-2"
              />
              <Label htmlFor="sort-nameAsc">Название: А-Я</Label>
            </div>
            <div className="flex items-center">
              <input
                type="radio"
                id="sort-nameDesc"
                name="sortBy"
                value="nameDesc"
                checked={sortBy === "nameDesc"}
                onChange={() => setSortBy("nameDesc")}
                className="mr-2"
              />
              <Label htmlFor="sort-nameDesc">Название: Я-А</Label>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Price Range */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-lg">Цена</CardTitle>
        </CardHeader>
        <CardContent>
          <Slider
            defaultValue={[0, 10000]}
            max={10000}
            step={100}
            value={priceRange}
            onValueChange={(value) => setPriceRange(value as [number, number])}
            className="my-6"
          />
          <div className="flex justify-between text-sm">
            <span>{formatCurrency(priceRange[0])}</span>
            <span>{formatCurrency(priceRange[1])}</span>
          </div>
        </CardContent>
      </Card>

      {/* Colors */}
      {colors && colors.length > 0 && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">Цвет</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {colors.map((color: any) => (
                <div key={color.id} className="flex items-center">
                  <Checkbox
                    id={`color-${color.id}`}
                    checked={selectedColors.includes(color.id.toString())}
                    onCheckedChange={() => handleColorToggle(color.id.toString())}
                    className="mr-2"
                  />
                  <Label 
                    htmlFor={`color-${color.id}`}
                    className="flex items-center"
                  >
                    <span 
                      className="w-4 h-4 rounded-full mr-2 inline-block border border-gray-300" 
                      style={{ backgroundColor: color.value }}
                    ></span>
                    {color.name}
                  </Label>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Sizes */}
      {sizes && sizes.length > 0 && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">Размер</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {sizes.map((size: any) => (
                <div key={size.id} className="flex items-center">
                  <Checkbox
                    id={`size-${size.id}`}
                    checked={selectedSizes.includes(size.id.toString())}
                    onCheckedChange={() => handleSizeToggle(size.id.toString())}
                    className="mr-2"
                  />
                  <Label htmlFor={`size-${size.id}`}>{size.name}</Label>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
