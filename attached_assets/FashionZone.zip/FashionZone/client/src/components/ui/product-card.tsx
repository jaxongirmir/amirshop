import { Heart } from "lucide-react";
import { Button } from "./button";
import { useState } from "react";
import { Link } from "wouter";
import { ColorSelector } from "./color-selector";
import { formatCurrency } from "@/lib/utils";

export interface ProductCardProps {
  id: number;
  name: string;
  slug: string;
  price: number;
  compareAtPrice?: number | null;
  imageUrl: string;
  rating?: number | null;
  isNew?: boolean;
  isSale?: boolean;
  sizes?: Array<{ id: number; name: string; value: string }>;
  colors?: Array<{ id: number; name: string; value: string }>;
  categoryType?: string;
}

export function ProductCard({
  id,
  name,
  slug,
  price,
  compareAtPrice,
  imageUrl,
  rating,
  isNew,
  isSale,
  sizes,
  colors
}: ProductCardProps) {
  const [selectedColor, setSelectedColor] = useState<string | null>(null);
  
  const discount = compareAtPrice ? Math.round((1 - (price / compareAtPrice)) * 100) : 0;

  return (
    <div className="product-card bg-white rounded-lg overflow-hidden shadow-sm group">
      <div className="relative overflow-hidden">
        <Link href={`/products/${slug}`}>
          <img 
            src={imageUrl} 
            alt={name} 
            className="w-full h-[240px] md:h-[300px] object-cover product-image transition-transform duration-300"
          />
        </Link>
        
        {/* Product labels */}
        <div className="absolute top-3 left-3 flex flex-col gap-2">
          {isNew && (
            <span className="bg-accent text-white text-xs font-bold py-1 px-2 rounded">NEW</span>
          )}
          {isSale && discount > 0 && (
            <span className="bg-secondary text-white text-xs font-bold py-1 px-2 rounded">-{discount}%</span>
          )}
        </div>
        
        {/* Wishlist button */}
        <div className="absolute top-3 right-3">
          <button className="bg-white w-8 h-8 rounded-full flex items-center justify-center text-gray-500 hover:text-secondary transition shadow-sm">
            <Heart className="h-4 w-4" />
          </button>
        </div>
        
        {/* Hover overlay */}
        <div className="absolute inset-0 bg-black/5 opacity-0 group-hover:opacity-100 transition-opacity"></div>
        
        {/* Quick actions */}
        <div className="absolute bottom-0 left-0 right-0 p-4 opacity-0 group-hover:opacity-100 transition-opacity quick-actions">
          <Link href={`/products/${slug}`}>
            <Button className="w-full" variant="secondary">
              Быстрый просмотр
            </Button>
          </Link>
        </div>
      </div>
      
      <div className="p-4">
        <div>
          <Link href={`/products/${slug}`} className="hover:text-primary transition">
            <h3 className="font-medium mb-1">{name}</h3>
          </Link>
          
          {sizes && sizes.length > 0 && (
            <div className="flex items-center gap-1 text-sm text-gray-500 mb-2">
              <span>Размеры:</span>
              <div className="flex gap-1">
                {sizes.slice(0, 5).map((size) => (
                  <span 
                    key={size.id} 
                    className={`text-xs ${selectedColor ? 'text-dark font-medium' : ''}`}
                  >
                    {size.name}
                  </span>
                ))}
              </div>
            </div>
          )}
        </div>
        
        <div className="flex items-center justify-between mt-2">
          <div className="flex items-center gap-2">
            <span className="font-bold text-lg">{formatCurrency(price)}</span>
            {compareAtPrice && (
              <span className="text-gray-500 line-through text-sm">{formatCurrency(compareAtPrice)}</span>
            )}
          </div>
          
          {rating && (
            <div className="text-sm flex items-center">
              <i className="fas fa-star text-warning text-xs mr-1"></i>
              <span>{typeof rating === 'number' ? rating.toFixed(1) : rating}</span>
            </div>
          )}
        </div>
        
        {colors && colors.length > 0 && (
          <div className="mt-2">
            <ColorSelector 
              colors={colors} 
              selectedColor={selectedColor} 
              onSelectColor={(color) => setSelectedColor(color)} 
              small
            />
          </div>
        )}
      </div>
    </div>
  );
}
