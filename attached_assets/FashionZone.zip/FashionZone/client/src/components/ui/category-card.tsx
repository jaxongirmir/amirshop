import { Link } from "wouter";
import { ArrowRight } from "lucide-react";

interface CategoryCardProps {
  name: string;
  slug: string;
  imageUrl: string;
}

export function CategoryCard({ name, slug, imageUrl }: CategoryCardProps) {
  return (
    <Link href={`/products/category/${slug}`} className="category-badge relative rounded-lg overflow-hidden group hover-zoom">
      <img 
        src={imageUrl} 
        alt={name} 
        className="w-full h-[180px] md:h-[250px] object-cover"
      />
      <div className="absolute inset-0 bg-gradient-to-t from-dark/70 to-transparent"></div>
      <div className="absolute bottom-0 left-0 right-0 p-4">
        <h3 className="text-xl font-bold text-white">{name}</h3>
        <div className="flex items-center text-white/80 text-sm mt-1">
          <span>Смотреть коллекцию</span>
          <ArrowRight className="ml-2 h-4 w-4 group-hover:ml-3 transition-all" />
        </div>
      </div>
    </Link>
  );
}
