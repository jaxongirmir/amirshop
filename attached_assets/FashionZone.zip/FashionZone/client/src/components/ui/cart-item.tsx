import { Button } from "./button";
import { Minus, Plus, X } from "lucide-react";
import { formatCurrency } from "@/lib/utils";
import { useCart } from "@/lib/cart-context";

interface CartItemProps {
  id: number;
  name: string;
  price: number;
  quantity: number;
  imageUrl: string;
  size?: string;
  color?: string;
  variantId?: number;
}

export function CartItem({ id, name, price, quantity, imageUrl, size, color }: CartItemProps) {
  const { updateCartItem, removeCartItem } = useCart();

  const handleQuantityChange = (newQuantity: number) => {
    if (newQuantity > 0) {
      updateCartItem(id, newQuantity);
    }
  };

  const handleRemove = () => {
    removeCartItem(id);
  };

  return (
    <div className="flex border-b pb-4">
      <div className="w-20 h-24 bg-gray-100 rounded flex-shrink-0 overflow-hidden">
        <img src={imageUrl} alt={name} className="w-full h-full object-cover" />
      </div>
      
      <div className="ml-4 flex-grow">
        <div className="flex justify-between">
          <h4 className="font-medium">{name}</h4>
          <button 
            className="text-gray-500 hover:text-destructive"
            onClick={handleRemove}
          >
            <X className="h-4 w-4" />
          </button>
        </div>
        
        {(size || color) && (
          <div className="text-sm text-gray-600 mt-1">
            {size && <span>Размер: {size}</span>}
            {size && color && <span> | </span>}
            {color && <span>Цвет: {color}</span>}
          </div>
        )}
        
        <div className="flex justify-between items-end mt-2">
          <div className="flex items-center border rounded">
            <Button 
              variant="ghost" 
              size="sm" 
              className="px-2 h-8 text-gray-600 hover:bg-gray-100"
              onClick={() => handleQuantityChange(quantity - 1)}
            >
              <Minus className="h-3 w-3" />
            </Button>
            <span className="px-2 py-1">{quantity}</span>
            <Button 
              variant="ghost" 
              size="sm" 
              className="px-2 h-8 text-gray-600 hover:bg-gray-100"
              onClick={() => handleQuantityChange(quantity + 1)}
            >
              <Plus className="h-3 w-3" />
            </Button>
          </div>
          <div className="font-semibold">{formatCurrency(price * quantity)}</div>
        </div>
      </div>
    </div>
  );
}
