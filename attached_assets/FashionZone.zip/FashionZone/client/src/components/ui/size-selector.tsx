import { cn } from "@/lib/utils";

interface Size {
  id: number;
  name: string;
  value: string;
}

interface SizeSelectorProps {
  sizes: Size[];
  selectedSize: string | null;
  onSelectSize: (value: string) => void;
  disabled?: boolean;
}

export function SizeSelector({ sizes, selectedSize, onSelectSize, disabled = false }: SizeSelectorProps) {
  console.log("Sizes in selector:", sizes);
  console.log("Selected size:", selectedSize);
  
  return (
    <div className="flex flex-wrap gap-2">
      {sizes.map((size) => (
        <button
          key={size.id}
          className={cn(
            "min-w-[40px] h-10 px-3 border text-sm font-medium rounded transition-all",
            selectedSize === String(size.id)
              ? 'border-primary bg-primary/10 text-primary'
              : 'border-gray-300 bg-white text-gray-700 hover:border-gray-400',
            disabled && "opacity-50 cursor-not-allowed"
          )}
          onClick={() => onSelectSize(String(size.id))}
          disabled={disabled}
        >
          {size.name}
        </button>
      ))}
    </div>
  );
}