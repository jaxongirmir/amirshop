import { Link } from "wouter";
import { useCart } from "@/lib/cart-context";
import { CartItem } from "@/components/ui/cart-item";
import { Button } from "@/components/ui/button";
import { formatCurrency } from "@/lib/utils";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { ShoppingCart, ArrowRight, Loader2 } from "lucide-react";

export default function CartPage() {
  const { cart, loading, clearCart } = useCart();
  
  // Calculate totals
  const subtotal = cart?.cartItems?.reduce((total, item) => {
    return total + (item.product.price * item.quantity);
  }, 0) || 0;
  
  const shippingCost = subtotal > 0 ? 350 : 0;
  const total = subtotal + shippingCost;
  
  // Empty cart view
  if (!loading && (!cart || cart.cartItems.length === 0)) {
    return (
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-2xl mx-auto text-center">
          <div className="text-gray-400 mb-6">
            <ShoppingCart className="h-20 w-20 mx-auto" />
          </div>
          <h1 className="text-3xl font-bold mb-4">Ваша корзина пуста</h1>
          <p className="text-gray-600 mb-8">
            Похоже, вы еще не добавили товары в корзину.
            Начните покупки прямо сейчас!
          </p>
          <Link href="/products">
            <Button size="lg" className="px-8">
              Перейти в каталог
            </Button>
          </Link>
        </div>
      </div>
    );
  }
  
  return (
    <div className="container mx-auto px-4 py-12">
      <h1 className="text-3xl font-bold mb-8">Корзина</h1>
      
      {loading ? (
        <div className="flex justify-center items-center h-60">
          <Loader2 className="h-12 w-12 animate-spin text-primary" />
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Cart items */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle>Товары ({cart?.cartItems.length || 0})</CardTitle>
                <CardDescription>
                  Ваши выбранные товары в корзине
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {cart?.cartItems.map((item) => (
                  <CartItem
                    key={item.id}
                    id={item.id}
                    name={item.product.name}
                    price={item.product.price}
                    quantity={item.quantity}
                    imageUrl={item.product.imageUrl}
                    size={item.variant?.size?.name}
                    color={item.variant?.color?.name}
                    variantId={item.variantId}
                  />
                ))}
              </CardContent>
              <CardFooter className="flex justify-between">
                <Button variant="outline" onClick={clearCart}>
                  Очистить корзину
                </Button>
                <Link href="/products">
                  <Button variant="link" className="text-primary">
                    Продолжить покупки
                  </Button>
                </Link>
              </CardFooter>
            </Card>
          </div>
          
          {/* Order summary */}
          <div>
            <Card>
              <CardHeader>
                <CardTitle>Итого</CardTitle>
                <CardDescription>
                  Сводка по заказу
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between">
                  <span className="text-gray-600">Товары ({cart?.cartItems.length || 0}):</span>
                  <span>{formatCurrency(subtotal)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Доставка:</span>
                  <span>{formatCurrency(shippingCost)}</span>
                </div>
                <Separator />
                <div className="flex justify-between font-bold text-lg">
                  <span>Итого:</span>
                  <span>{formatCurrency(total)}</span>
                </div>
              </CardContent>
              <CardFooter>
                <Link href="/checkout" className="w-full">
                  <Button className="w-full" size="lg">
                    Оформить заказ
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </Link>
              </CardFooter>
            </Card>
            
            {/* Delivery info */}
            <div className="mt-6 bg-white rounded-lg p-4 text-sm">
              <h3 className="font-medium mb-2">Информация о доставке</h3>
              <ul className="space-y-2 text-gray-600">
                <li className="flex items-start">
                  <i className="fas fa-truck mt-1 mr-2 text-primary"></i>
                  <span>Срок доставки: 1-3 рабочих дня</span>
                </li>
                <li className="flex items-start">
                  <i className="fas fa-credit-card mt-1 mr-2 text-primary"></i>
                  <span>Несколько способов оплаты</span>
                </li>
                <li className="flex items-start">
                  <i className="fas fa-undo mt-1 mr-2 text-primary"></i>
                  <span>30 дней на возврат товара</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
