import { useState } from "react";
import { useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useAuth } from "@/hooks/use-auth";
import { useCart } from "@/lib/cart-context";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { formatCurrency } from "@/lib/utils";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Textarea } from "@/components/ui/textarea";
import { Loader2, CreditCard, Truck, MapPin } from "lucide-react";

const formSchema = z.object({
  firstName: z.string().min(2, { message: "Имя должно содержать не менее 2 символов" }),
  lastName: z.string().min(2, { message: "Фамилия должна содержать не менее 2 символов" }),
  email: z.string().email({ message: "Введите корректный email" }),
  phone: z.string().min(10, { message: "Введите корректный номер телефона" }),
  address: z.string().min(5, { message: "Укажите полный адрес доставки" }),
  city: z.string().min(2, { message: "Укажите город" }),
  zipCode: z.string().min(5, { message: "Укажите корректный почтовый индекс" }),
  country: z.string().min(2, { message: "Укажите страну" }),
  paymentMethod: z.enum(["card", "cash"], {
    required_error: "Выберите способ оплаты",
  }),
  comment: z.string().optional(),
});

type FormData = z.infer<typeof formSchema>;

export default function CheckoutPage() {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [, navigate] = useLocation();
  const { user } = useAuth();
  const { cart, loading: cartLoading } = useCart();
  const { toast } = useToast();
  
  // Calculate totals
  const subtotal = cart?.cartItems?.reduce((total, item) => {
    return total + (item.product.price * item.quantity);
  }, 0) || 0;
  
  const shippingCost = subtotal > 0 ? 350 : 0;
  const total = subtotal + shippingCost;
  
  // Form with default values from user profile
  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      firstName: user?.firstName || "",
      lastName: user?.lastName || "",
      email: user?.email || "",
      phone: user?.phone || "",
      address: user?.address || "",
      city: user?.city || "",
      zipCode: user?.zipCode || "",
      country: user?.country || "Россия",
      paymentMethod: "card",
      comment: "",
    },
  });
  
  const onSubmit = async (data: FormData) => {
    if (!cart || cart.cartItems.length === 0) {
      toast({
        title: "Корзина пуста",
        description: "Добавьте товары в корзину перед оформлением заказа",
        variant: "destructive",
      });
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      // Prepare order data
      const orderData = {
        shippingAddress: data.address,
        shippingCity: data.city,
        shippingZipCode: data.zipCode,
        shippingCountry: data.country,
        paymentMethod: data.paymentMethod,
        total,
        shippingCost,
        items: cart.cartItems.map(item => ({
          productId: item.product.id,
          variantId: item.variantId || null,
          quantity: item.quantity,
          price: item.product.price
        }))
      };
      
      // Create order
      const response = await apiRequest("POST", "/api/orders", orderData);
      const order = await response.json();
      
      // Show success message
      toast({
        title: "Заказ успешно создан",
        description: `Номер вашего заказа: ${order.id}`,
      });
      
      // Clear cart cache
      queryClient.invalidateQueries({ queryKey: ['/api/cart'] });
      
      // Redirect to order details page
      navigate(`/orders/${order.id}`);
    } catch (error) {
      console.error("Error creating order:", error);
      toast({
        title: "Ошибка при создании заказа",
        description: error instanceof Error ? error.message : "Попробуйте еще раз позже",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };
  
  if (cartLoading) {
    return (
      <div className="container mx-auto px-4 py-12 flex justify-center">
        <Loader2 className="h-12 w-12 animate-spin text-primary" />
      </div>
    );
  }
  
  if (!cart || cart.cartItems.length === 0) {
    return (
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-2xl mx-auto text-center">
          <div className="text-gray-400 mb-6">
            <i className="fas fa-shopping-bag text-6xl"></i>
          </div>
          <h1 className="text-3xl font-bold mb-4">Корзина пуста</h1>
          <p className="text-gray-600 mb-8">
            Для оформления заказа необходимо добавить товары в корзину.
          </p>
          <Button onClick={() => navigate("/products")}>
            Перейти в каталог
          </Button>
        </div>
      </div>
    );
  }
  
  return (
    <div className="container mx-auto px-4 py-12">
      <h1 className="text-3xl font-bold mb-8">Оформление заказа</h1>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Checkout form */}
        <div className="lg:col-span-2">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)}>
              <Card className="mb-8">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <MapPin className="mr-2 h-5 w-5" />
                    Контактная информация
                  </CardTitle>
                  <CardDescription>
                    Введите контактные данные для доставки заказа
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="firstName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Имя</FormLabel>
                          <FormControl>
                            <Input placeholder="Иван" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="lastName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Фамилия</FormLabel>
                          <FormControl>
                            <Input placeholder="Иванов" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email</FormLabel>
                          <FormControl>
                            <Input placeholder="example@mail.ru" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="phone"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Телефон</FormLabel>
                          <FormControl>
                            <Input placeholder="+7 (999) 123-45-67" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </CardContent>
              </Card>
              
              <Card className="mb-8">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Truck className="mr-2 h-5 w-5" />
                    Адрес доставки
                  </CardTitle>
                  <CardDescription>
                    Введите адрес для доставки заказа
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <FormField
                    control={form.control}
                    name="address"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Адрес</FormLabel>
                        <FormControl>
                          <Input placeholder="ул. Примерная, д. 1, кв. 123" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <FormField
                      control={form.control}
                      name="city"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Город</FormLabel>
                          <FormControl>
                            <Input placeholder="Москва" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="zipCode"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Индекс</FormLabel>
                          <FormControl>
                            <Input placeholder="123456" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="country"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Страна</FormLabel>
                          <FormControl>
                            <Input placeholder="Россия" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <FormField
                    control={form.control}
                    name="comment"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Комментарий к заказу</FormLabel>
                        <FormControl>
                          <Textarea 
                            placeholder="Дополнительная информация для курьера или магазина" 
                            {...field} 
                          />
                        </FormControl>
                        <FormDescription>
                          Необязательное поле
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </CardContent>
              </Card>
              
              <Card className="mb-8">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <CreditCard className="mr-2 h-5 w-5" />
                    Способ оплаты
                  </CardTitle>
                  <CardDescription>
                    Выберите удобный способ оплаты
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <FormField
                    control={form.control}
                    name="paymentMethod"
                    render={({ field }) => (
                      <FormItem>
                        <FormControl>
                          <RadioGroup
                            onValueChange={field.onChange}
                            defaultValue={field.value}
                            className="space-y-4"
                          >
                            <FormItem className="flex items-center space-x-3 space-y-0">
                              <FormControl>
                                <RadioGroupItem value="card" />
                              </FormControl>
                              <FormLabel className="font-normal cursor-pointer flex items-center">
                                <span className="bg-white/10 p-1 rounded inline-block mr-2">
                                  <i className="fab fa-cc-visa text-xl"></i>
                                </span>
                                Оплата банковской картой онлайн
                              </FormLabel>
                            </FormItem>
                            <FormItem className="flex items-center space-x-3 space-y-0">
                              <FormControl>
                                <RadioGroupItem value="cash" />
                              </FormControl>
                              <FormLabel className="font-normal cursor-pointer">
                                Оплата при получении
                              </FormLabel>
                            </FormItem>
                          </RadioGroup>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="pt-6">
                  <Button 
                    type="submit" 
                    className="w-full" 
                    size="lg"
                    disabled={isSubmitting}
                  >
                    {isSubmitting ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Оформление заказа...
                      </>
                    ) : (
                      "Оформить заказ"
                    )}
                  </Button>
                </CardContent>
              </Card>
            </form>
          </Form>
        </div>
        
        {/* Order summary */}
        <div>
          <Card className="sticky top-24">
            <CardHeader>
              <CardTitle>Ваш заказ</CardTitle>
              <CardDescription>
                {cart.cartItems.length} {cart.cartItems.length === 1 ? 'товар' : 
                  cart.cartItems.length > 1 && cart.cartItems.length < 5 ? 'товара' : 'товаров'}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="max-h-80 overflow-y-auto pr-2">
                {cart.cartItems.map((item) => (
                  <div key={item.id} className="flex py-3 border-b">
                    <div className="w-16 h-16 bg-gray-100 rounded flex-shrink-0 overflow-hidden">
                      <img 
                        src={item.product.imageUrl} 
                        alt={item.product.name} 
                        className="w-full h-full object-cover" 
                      />
                    </div>
                    <div className="ml-3 flex-grow">
                      <div className="flex justify-between">
                        <h4 className="font-medium text-sm">{item.product.name}</h4>
                        <span className="font-medium text-sm">
                          {formatCurrency(item.product.price * item.quantity)}
                        </span>
                      </div>
                      <div className="text-xs text-gray-600 mt-1">
                        {item.variant?.size?.name && <span>Размер: {item.variant.size.name}</span>}
                        {item.variant?.size?.name && item.variant?.color?.name && <span> | </span>}
                        {item.variant?.color?.name && <span>Цвет: {item.variant.color.name}</span>}
                      </div>
                      <div className="text-xs text-gray-600 mt-1">
                        Количество: {item.quantity}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              
              <Separator />
              
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-gray-600">Товары:</span>
                  <span>{formatCurrency(subtotal)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Доставка:</span>
                  <span>{formatCurrency(shippingCost)}</span>
                </div>
              </div>
              
              <Separator />
              
              <div className="flex justify-between font-bold text-lg">
                <span>Итого:</span>
                <span>{formatCurrency(total)}</span>
              </div>
            </CardContent>
            <CardFooter>
              <div className="w-full text-sm text-gray-600">
                <p className="mb-2">
                  Нажимая кнопку "Оформить заказ", вы соглашаетесь с нашими{" "}
                  <a href="/terms" className="text-primary underline">условиями использования</a>
                  {" "}и{" "}
                  <a href="/privacy" className="text-primary underline">политикой конфиденциальности</a>.
                </p>
              </div>
            </CardFooter>
          </Card>
          
          {/* Delivery info */}
          <div className="mt-6">
            <Tabs defaultValue="delivery">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="delivery">Доставка</TabsTrigger>
                <TabsTrigger value="payment">Оплата</TabsTrigger>
              </TabsList>
              <TabsContent value="delivery" className="mt-4 text-sm">
                <div className="bg-white rounded-lg p-4 shadow-sm">
                  <h3 className="font-medium mb-2">Информация о доставке</h3>
                  <ul className="space-y-2 text-gray-600">
                    <li className="flex items-start">
                      <i className="fas fa-truck mt-1 mr-2 text-primary"></i>
                      <span>Курьерская доставка: 1-3 рабочих дня</span>
                    </li>
                    <li className="flex items-start">
                      <i className="fas fa-box mt-1 mr-2 text-primary"></i>
                      <span>Доставка в пункт выдачи: 1-2 рабочих дня</span>
                    </li>
                    <li className="flex items-start">
                      <i className="fas fa-info-circle mt-1 mr-2 text-primary"></i>
                      <span>Бесплатная доставка при заказе от 5000 ₽</span>
                    </li>
                  </ul>
                </div>
              </TabsContent>
              <TabsContent value="payment" className="mt-4 text-sm">
                <div className="bg-white rounded-lg p-4 shadow-sm">
                  <h3 className="font-medium mb-2">Способы оплаты</h3>
                  <ul className="space-y-2 text-gray-600">
                    <li className="flex items-start">
                      <i className="fas fa-credit-card mt-1 mr-2 text-primary"></i>
                      <span>Банковские карты Visa, Mastercard, МИР</span>
                    </li>
                    <li className="flex items-start">
                      <i className="fas fa-money-bill-wave mt-1 mr-2 text-primary"></i>
                      <span>Наличными при получении</span>
                    </li>
                    <li className="flex items-start">
                      <i className="fas fa-shield-alt mt-1 mr-2 text-primary"></i>
                      <span>Безопасная оплата с шифрованием данных</span>
                    </li>
                  </ul>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </div>
  );
}
