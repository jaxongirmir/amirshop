import { Link, useParams, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { formatCurrency } from "@/lib/utils";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Loader2, Package, Truck, MapPin, CalendarClock, CheckCircle2, AlertTriangle } from "lucide-react";

// Order status badge colors
const getStatusColor = (status: string) => {
  switch (status) {
    case "pending":
      return "bg-yellow-100 text-yellow-800 hover:bg-yellow-100";
    case "processing":
      return "bg-blue-100 text-blue-800 hover:bg-blue-100";
    case "shipped":
      return "bg-indigo-100 text-indigo-800 hover:bg-indigo-100";
    case "delivered":
      return "bg-green-100 text-green-800 hover:bg-green-100";
    case "cancelled":
      return "bg-red-100 text-red-800 hover:bg-red-100";
    default:
      return "bg-gray-100 text-gray-800 hover:bg-gray-100";
  }
};

// Format status for display
const formatStatus = (status: string) => {
  const statusMap: Record<string, string> = {
    pending: "Ожидает обработки",
    processing: "В обработке",
    shipped: "Отправлен",
    delivered: "Доставлен",
    cancelled: "Отменен"
  };
  
  return statusMap[status] || status;
};

// Format date for display
const formatDate = (dateString: string) => {
  const date = new Date(dateString);
  return date.toLocaleDateString('ru-RU', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
};

// Get status icon
const getStatusIcon = (status: string) => {
  switch (status) {
    case "pending":
      return <CalendarClock className="h-5 w-5 text-yellow-600" />;
    case "processing":
      return <Package className="h-5 w-5 text-blue-600" />;
    case "shipped":
      return <Truck className="h-5 w-5 text-indigo-600" />;
    case "delivered":
      return <CheckCircle2 className="h-5 w-5 text-green-600" />;
    case "cancelled":
      return <AlertTriangle className="h-5 w-5 text-red-600" />;
    default:
      return <Package className="h-5 w-5" />;
  }
};

export default function OrderDetailPage() {
  const { id } = useParams();
  const [, navigate] = useLocation();
  const { user } = useAuth();
  
  // Fetch order details
  const { data: order, isLoading, isError } = useQuery({
    queryKey: ["/api/orders", id],
    queryFn: () => fetch(`/api/orders/${id}`).then(res => res.json()),
    enabled: !!id && !!user,
  });
  
  if (!user) {
    return (
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-2xl mx-auto text-center">
          <h1 className="text-3xl font-bold mb-4">Доступ запрещен</h1>
          <p className="text-gray-600 mb-8">
            Для доступа к информации о заказе необходимо войти в аккаунт.
          </p>
          <Link href="/auth">
            <Button>Войти в аккаунт</Button>
          </Link>
        </div>
      </div>
    );
  }
  
  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-12 flex justify-center">
        <Loader2 className="h-12 w-12 animate-spin text-primary" />
      </div>
    );
  }
  
  if (isError || !order) {
    return (
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-2xl mx-auto text-center">
          <h1 className="text-3xl font-bold mb-4">Заказ не найден</h1>
          <p className="text-gray-600 mb-8">
            Информация о запрашиваемом заказе недоступна. Возможно, заказ был удален или у вас нет прав доступа к нему.
          </p>
          <Link href="/orders">
            <Button>Вернуться к списку заказов</Button>
          </Link>
        </div>
      </div>
    );
  }
  
  // Calculate totals
  const subtotal = order.orderItems.reduce((total: number, item: any) => {
    return total + (item.price * item.quantity);
  }, 0);
  
  return (
    <div className="container mx-auto px-4 py-12">
      {/* Breadcrumbs */}
      <Breadcrumb className="mb-6">
        <BreadcrumbList>
          <BreadcrumbItem>
            <BreadcrumbLink href="/">Главная</BreadcrumbLink>
            <BreadcrumbSeparator />
          </BreadcrumbItem>
          <BreadcrumbItem>
            <BreadcrumbLink href="/orders">Мои заказы</BreadcrumbLink>
            <BreadcrumbSeparator />
          </BreadcrumbItem>
          <BreadcrumbItem>
            <BreadcrumbPage>Заказ №{order.id}</BreadcrumbPage>
          </BreadcrumbItem>
        </BreadcrumbList>
      </Breadcrumb>
      
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">Заказ №{order.id}</h1>
        <Badge variant="outline" className={`${getStatusColor(order.status)} text-sm py-1 px-3`}>
          {formatStatus(order.status)}
        </Badge>
      </div>
      
      {/* Order status alert for special statuses */}
      {order.status === "cancelled" && (
        <Alert variant="destructive" className="mb-6">
          <AlertTriangle className="h-4 w-4" />
          <AlertTitle>Заказ отменен</AlertTitle>
          <AlertDescription>
            Данный заказ был отменен. Если у вас возникли вопросы, свяжитесь с нашей службой поддержки.
          </AlertDescription>
        </Alert>
      )}
      
      {order.status === "delivered" && (
        <Alert className="mb-6 border-green-200 text-green-800">
          <CheckCircle2 className="h-4 w-4" />
          <AlertTitle>Заказ доставлен</AlertTitle>
          <AlertDescription>
            Заказ был успешно доставлен. Спасибо за покупку!
          </AlertDescription>
        </Alert>
      )}
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Order items */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Package className="mr-2 h-5 w-5" />
                Товары в заказе
              </CardTitle>
              <CardDescription>
                {order.orderItems.length} {
                  order.orderItems.length === 1 ? 'товар' : 
                  order.orderItems.length > 1 && order.orderItems.length < 5 ? 'товара' : 'товаров'
                }
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {order.orderItems.map((item: any) => (
                  <div key={item.id} className="flex border-b pb-4">
                    <div className="w-20 h-24 bg-gray-100 rounded flex-shrink-0 overflow-hidden">
                      <img 
                        src={item.product.imageUrl} 
                        alt={item.product.name} 
                        className="w-full h-full object-cover" 
                      />
                    </div>
                    <div className="ml-4 flex-grow">
                      <div className="flex justify-between">
                        <Link href={`/products/${item.product.slug}`}>
                          <h4 className="font-medium hover:text-primary transition">{item.product.name}</h4>
                        </Link>
                        <span className="font-medium">{formatCurrency(item.price * item.quantity)}</span>
                      </div>
                      <div className="text-sm text-gray-600 mt-1">
                        {item.variant?.size?.name && <span>Размер: {item.variant.size.name}</span>}
                        {item.variant?.size?.name && item.variant?.color?.name && <span> | </span>}
                        {item.variant?.color?.name && <span>Цвет: {item.variant.color.name}</span>}
                      </div>
                      <div className="text-sm text-gray-600 mt-1">
                        {formatCurrency(item.price)} × {item.quantity} шт.
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
            <CardFooter className="flex justify-end">
              {order.status !== "cancelled" && (
                <Link href="/products">
                  <Button variant="outline">Купить снова</Button>
                </Link>
              )}
            </CardFooter>
          </Card>
          
          {/* Delivery information */}
          <Card className="mt-6">
            <CardHeader>
              <CardTitle className="flex items-center">
                <MapPin className="mr-2 h-5 w-5" />
                Информация о доставке
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <h3 className="font-medium mb-2">Адрес доставки</h3>
                    <p className="text-gray-600">{order.shippingAddress}</p>
                    <p className="text-gray-600">{order.shippingCity}, {order.shippingZipCode}</p>
                    <p className="text-gray-600">{order.shippingCountry}</p>
                  </div>
                  <div>
                    <h3 className="font-medium mb-2">Способ оплаты</h3>
                    <p className="text-gray-600">
                      {order.paymentMethod === "card" ? "Банковская карта" : "Оплата при получении"}
                    </p>
                  </div>
                </div>
                <Separator />
                <div>
                  <h3 className="font-medium mb-2">Статус заказа</h3>
                  <div className="flex items-center">
                    {getStatusIcon(order.status)}
                    <div className="ml-2">
                      <p className="font-medium">{formatStatus(order.status)}</p>
                      <p className="text-sm text-gray-600">
                        Последнее обновление: {formatDate(order.updatedAt)}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
        
        {/* Order summary */}
        <div>
          <Card>
            <CardHeader>
              <CardTitle>Сводка заказа</CardTitle>
              <CardDescription>
                Оформлен {formatDate(order.createdAt)}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <div className="flex justify-between mb-2">
                  <span className="text-gray-600">Товары:</span>
                  <span>{formatCurrency(subtotal)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Доставка:</span>
                  <span>{formatCurrency(order.shippingCost)}</span>
                </div>
              </div>
              
              <Separator />
              
              <div className="flex justify-between font-bold text-lg">
                <span>Итого:</span>
                <span>{formatCurrency(order.total)}</span>
              </div>
            </CardContent>
            <CardFooter className="flex flex-col space-y-4">
              <Button 
                className="w-full" 
                onClick={() => navigate("/orders")}
              >
                Вернуться к заказам
              </Button>
              <Button 
                variant="outline" 
                className="w-full"
                onClick={() => window.print()}
              >
                Распечатать заказ
              </Button>
            </CardFooter>
          </Card>
          
          {/* Need help section */}
          <div className="mt-6 bg-white rounded-lg p-4 border shadow-sm">
            <h3 className="font-medium mb-2">Нужна помощь?</h3>
            <p className="text-sm text-gray-600 mb-4">
              Если у вас возникли вопросы по заказу, вы можете связаться с нашей службой поддержки.
            </p>
            <div className="space-y-2 text-sm">
              <div className="flex items-center">
                <i className="fas fa-phone mr-2 text-primary"></i>
                <span>+7 (495) 123-45-67</span>
              </div>
              <div className="flex items-center">
                <i className="fas fa-envelope mr-2 text-primary"></i>
                <span>support@fashionhub.ru</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
