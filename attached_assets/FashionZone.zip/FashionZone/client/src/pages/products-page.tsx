import { useState, useEffect } from "react";
import { useLocation, useParams } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { 
  Breadcrumb, 
  BreadcrumbItem,
  BreadcrumbLink, 
  BreadcrumbList, 
  BreadcrumbPage, 
  BreadcrumbSeparator 
} from "@/components/ui/breadcrumb";
import { Filters } from "@/components/ui/filters";
import { ProductCard } from "@/components/ui/product-card";
import { Button } from "@/components/ui/button";
import { FilterIcon, ChevronLeft, ChevronRight } from "lucide-react";
import { 
  Sheet, 
  SheetContent, 
  SheetDescription, 
  SheetHeader, 
  SheetTitle, 
  SheetTrigger 
} from "@/components/ui/sheet";

export default function ProductsPage() {
  const [location] = useLocation();
  const params = useParams();
  const { category } = params;
  
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize] = useState(12);
  const [filters, setFilters] = useState<{
    minPrice?: number;
    maxPrice?: number;
    colors?: string[];
    sizes?: string[];
    sortBy?: string;
    categoryType?: string;
    categoryId?: number;
    isNew?: boolean;
  }>({});
  
  // Parse query parameters from URL
  useEffect(() => {
    const searchParams = new URLSearchParams(location.split('?')[1]);
    const newFilters: any = {};
    
    if (searchParams.get('isNew')) {
      newFilters.isNew = searchParams.get('isNew') === 'true';
    }
    
    if (searchParams.get('search')) {
      newFilters.search = searchParams.get('search');
    }
    
    if (Object.keys(newFilters).length > 0) {
      setFilters(prev => ({ ...prev, ...newFilters }));
    }
  }, [location]);
  
  // Fetch category if provided
  const { data: categoryData } = useQuery({
    queryKey: ["/api/categories", category],
    queryFn: () => 
      category ? fetch(`/api/categories/${category}`).then(res => res.json()) : null,
    enabled: !!category
  });
  
  // Update filters based on category
  useEffect(() => {
    if (categoryData) {
      // Get category type from slug (assuming women, men, children, accessories are main categories)
      let categoryType = "";
      if (category === "women") categoryType = "women";
      else if (category === "men") categoryType = "men";
      else if (category === "children") categoryType = "children";
      else if (category === "accessories") categoryType = "accessories";
      
      console.log("Category data:", categoryData);
      console.log("Setting categoryType to:", categoryType);
      
      setFilters(prev => ({
        ...prev,
        categoryId: categoryData.id,
        categoryType: categoryType || categoryData.categoryType || undefined
      }));
    }
  }, [categoryData, category]);
  
  // Fetch products with filters
  const { data: productsData, isLoading } = useQuery({
    queryKey: ["/api/products", {
      page: currentPage,
      limit: pageSize,
      ...filters
    }],
    queryFn: () => {
      const searchParams = new URLSearchParams();
      searchParams.append('page', currentPage.toString());
      searchParams.append('limit', pageSize.toString());
      
      if (filters.minPrice !== undefined) searchParams.append('minPrice', filters.minPrice.toString());
      if (filters.maxPrice !== undefined) searchParams.append('maxPrice', filters.maxPrice.toString());
      if (filters.sortBy) searchParams.append('sortBy', filters.sortBy);
      if (filters.categoryType) searchParams.append('categoryType', filters.categoryType);
      if (filters.categoryId) searchParams.append('categoryId', filters.categoryId.toString());
      if (filters.isNew !== undefined) searchParams.append('isNew', filters.isNew.toString());
      if (filters.colors?.length) filters.colors.forEach(color => searchParams.append('color', color));
      if (filters.sizes?.length) filters.sizes.forEach(size => searchParams.append('size', size));
      
      return fetch(`/api/products?${searchParams.toString()}`).then(res => res.json());
    }
  });
  
  const products = productsData?.products || [];
  const totalPages = productsData ? Math.ceil(productsData.total / pageSize) : 0;
  
  const handleFilterChange = (newFilters: any) => {
    setFilters(prev => ({ ...prev, ...newFilters }));
    setCurrentPage(1); // Reset to first page when filters change
  };
  
  const handlePageChange = (page: number) => {
    if (page > 0 && page <= totalPages) {
      setCurrentPage(page);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };
  
  // Build breadcrumb path
  const breadcrumbs = [];
  breadcrumbs.push({ label: "Главная", href: "/" });
  
  if (categoryData) {
    if (categoryData.parent) {
      breadcrumbs.push({
        label: categoryData.parent.name,
        href: `/products/category/${categoryData.parent.slug}`
      });
    }
    breadcrumbs.push({
      label: categoryData.name,
      href: `/products/category/${categoryData.slug}`
    });
  } else if (filters.isNew) {
    breadcrumbs.push({ label: "Новинки", href: "/products?isNew=true" });
  } else {
    breadcrumbs.push({ label: "Все товары", href: "/products" });
  }
  
  // Page title
  const pageTitle = categoryData ? categoryData.name : filters.isNew ? "Новинки" : "Все товары";
  
  return (
    <div className="bg-gray-light py-6 md:py-12">
      <div className="container mx-auto px-4">
        {/* Breadcrumbs */}
        <Breadcrumb className="mb-6">
          <BreadcrumbList>
            {breadcrumbs.map((crumb, index) => (
              <BreadcrumbItem key={index}>
                {index < breadcrumbs.length - 1 ? (
                  <>
                    <BreadcrumbLink href={crumb.href}>{crumb.label}</BreadcrumbLink>
                    <BreadcrumbSeparator />
                  </>
                ) : (
                  <BreadcrumbPage>{crumb.label}</BreadcrumbPage>
                )}
              </BreadcrumbItem>
            ))}
          </BreadcrumbList>
        </Breadcrumb>
        
        <div className="flex flex-col md:flex-row gap-8">
          {/* Filters for desktop */}
          <div className="hidden md:block w-64 flex-shrink-0">
            <Filters 
              categoryType={filters.categoryType} 
              onFilterChange={handleFilterChange} 
            />
          </div>
          
          {/* Mobile filters button */}
          <div className="md:hidden mb-4">
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="outline" className="w-full flex items-center justify-center gap-2">
                  <FilterIcon className="h-4 w-4" />
                  Фильтры и сортировка
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="w-[300px] sm:w-[400px] overflow-y-auto">
                <SheetHeader>
                  <SheetTitle>Фильтры</SheetTitle>
                  <SheetDescription>
                    Настройте фильтры для поиска нужных товаров
                  </SheetDescription>
                </SheetHeader>
                <div className="py-4">
                  <Filters 
                    categoryType={filters.categoryType} 
                    onFilterChange={handleFilterChange} 
                  />
                </div>
              </SheetContent>
            </Sheet>
          </div>
          
          {/* Main content */}
          <div className="flex-1">
            <div className="flex justify-between items-center mb-6">
              <h1 className="text-2xl md:text-3xl font-bold">{pageTitle}</h1>
              <span className="text-sm text-gray-500">
                {productsData?.total || 0} товаров
              </span>
            </div>
            
            {isLoading ? (
              <div className="flex justify-center items-center h-96">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
              </div>
            ) : products.length === 0 ? (
              <div className="bg-white rounded-lg p-8 text-center">
                <div className="text-gray-400 mb-4">
                  <i className="fas fa-search text-5xl"></i>
                </div>
                <h3 className="text-xl font-bold mb-2">Товары не найдены</h3>
                <p className="text-gray-600 mb-4">
                  К сожалению, по вашему запросу ничего не найдено. Попробуйте изменить параметры фильтров.
                </p>
                <Button onClick={() => setFilters({})}>Сбросить фильтры</Button>
              </div>
            ) : (
              <>
                <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
                  {products.map((product: any) => (
                    <ProductCard
                      key={product.id}
                      id={product.id}
                      name={product.name}
                      slug={product.slug}
                      price={product.price}
                      compareAtPrice={product.compareAtPrice}
                      imageUrl={product.imageUrl}
                      rating={product.rating}
                      isNew={product.isNew}
                      isSale={product.compareAtPrice && product.compareAtPrice > product.price}
                      sizes={product.productVariants?.map((v: any) => v.size).filter(Boolean)}
                      colors={product.productVariants?.map((v: any) => v.color).filter(Boolean)}
                      categoryType={product.categoryType}
                    />
                  ))}
                </div>
                
                {/* Pagination */}
                {totalPages > 1 && (
                  <div className="flex justify-center mt-8">
                    <div className="flex items-center gap-2">
                      <Button
                        variant="outline"
                        size="icon"
                        disabled={currentPage === 1}
                        onClick={() => handlePageChange(currentPage - 1)}
                      >
                        <ChevronLeft className="h-4 w-4" />
                      </Button>
                      
                      {Array.from({ length: totalPages }, (_, i) => i + 1)
                        .filter(page => {
                          // Show first page, last page, and pages around current page
                          return (
                            page === 1 || 
                            page === totalPages || 
                            (page >= currentPage - 1 && page <= currentPage + 1)
                          );
                        })
                        .map((page, index, array) => {
                          // Add ellipsis when pages are skipped
                          const showEllipsisBefore = index > 0 && array[index - 1] !== page - 1;
                          
                          return (
                            <div key={page} className="flex items-center">
                              {showEllipsisBefore && (
                                <span className="mx-1">...</span>
                              )}
                              <Button
                                variant={page === currentPage ? "default" : "outline"}
                                size="icon"
                                onClick={() => handlePageChange(page)}
                                className="w-10 h-10"
                              >
                                {page}
                              </Button>
                            </div>
                          );
                        })}
                      
                      <Button
                        variant="outline"
                        size="icon"
                        disabled={currentPage === totalPages}
                        onClick={() => handlePageChange(currentPage + 1)}
                      >
                        <ChevronRight className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
