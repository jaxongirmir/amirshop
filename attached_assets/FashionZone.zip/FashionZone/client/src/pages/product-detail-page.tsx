import { useState } from "react";
import { useParams, Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { useCart } from "@/lib/cart-context";
import { 
  Breadcrumb, 
  BreadcrumbItem, 
  BreadcrumbLink, 
  BreadcrumbList, 
  BreadcrumbPage, 
  BreadcrumbSeparator 
} from "@/components/ui/breadcrumb";
import { Button } from "@/components/ui/button";
import { Heart, Minus, Plus, Check, Star } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ColorSelector } from "@/components/ui/color-selector";
import { SizeSelector } from "@/components/ui/size-selector";
import { ProductCard } from "@/components/ui/product-card";
import { formatCurrency } from "@/lib/utils";

export default function ProductDetailPage() {
  const { slug } = useParams();
  const { toast } = useToast();
  const { addToCart } = useCart();
  
  const [quantity, setQuantity] = useState(1);
  const [selectedColorId, setSelectedColorId] = useState<number | null>(null);
  const [selectedSizeId, setSelectedSizeId] = useState<number | null>(null);
  const [selectedVariantId, setSelectedVariantId] = useState<number | null>(null);
  
  // Fetch product details
  const { data: product, isLoading } = useQuery({
    queryKey: ["/api/products", slug],
    queryFn: () => fetch(`/api/products/${slug}`).then(res => res.json()),
    enabled: !!slug
  });
  
  // Fetch related products
  const { data: relatedProductsData } = useQuery({
    queryKey: ["/api/products", { categoryId: product?.categoryId, limit: 4 }],
    queryFn: () => 
      product?.categoryId 
        ? fetch(`/api/products?categoryId=${product.categoryId}&limit=4`)
            .then(res => res.json())
        : null,
    enabled: !!product?.categoryId
  });
  
  const relatedProducts = relatedProductsData?.products?.filter((p: any) => p.id !== product?.id) || [];
  
  // Extract unique colors and sizes from variants
  const colors = product?.productVariants
    ? Array.from(new Map(
        product.productVariants
          .filter((v: any) => v.color)
          .map((v: any) => [v.color.id, v.color])
      ).values())
    : [];
  
  const sizes = product?.productVariants
    ? Array.from(new Map(
        product.productVariants
          .filter((v: any) => v.size)
          .map((v: any) => [v.size.id, v.size])
      ).values())
    : [];
  
  // Find selected variant
  const selectedVariant = product?.productVariants?.find((v: any) => 
    (!selectedColorId || v.colorId === selectedColorId) && 
    (!selectedSizeId || v.sizeId === selectedSizeId)
  );
  
  // Update variant ID when color or size changes
  const updateVariant = () => {
    if (product?.productVariants) {
      const variant = product.productVariants.find((v: any) => 
        (!selectedColorId || v.colorId === selectedColorId) && 
        (!selectedSizeId || v.sizeId === selectedSizeId)
      );
      
      setSelectedVariantId(variant?.id || null);
    }
  };
  
  // Handle color selection
  const handleColorSelect = (colorId: number) => {
    setSelectedColorId(colorId);
    
    // If the current size is not available for this color, reset size
    const availableSizesForColor = product?.productVariants
      .filter((v: any) => v.colorId === colorId)
      .map((v: any) => v.sizeId);
    
    if (selectedSizeId && !availableSizesForColor?.includes(selectedSizeId)) {
      setSelectedSizeId(null);
    }
    
    updateVariant();
  };
  
  // Handle size selection
  const handleSizeSelect = (sizeId: number) => {
    setSelectedSizeId(sizeId);
    
    // If the current color is not available for this size, reset color
    const availableColorsForSize = product?.productVariants
      .filter((v: any) => v.sizeId === sizeId)
      .map((v: any) => v.colorId);
    
    if (selectedColorId && !availableColorsForSize?.includes(selectedColorId)) {
      setSelectedColorId(null);
    }
    
    updateVariant();
  };
  
  const handleQuantityChange = (value: number) => {
    if (value >= 1) {
      setQuantity(value);
    }
  };
  
  const handleAddToCart = () => {
    if (!product) return;
    
    // Validate selection
    if (sizes.length > 0 && !selectedSizeId) {
      toast({
        title: "Выберите размер",
        description: "Пожалуйста, выберите размер перед добавлением в корзину",
        variant: "destructive"
      });
      return;
    }
    
    if (colors.length > 0 && !selectedColorId) {
      toast({
        title: "Выберите цвет",
        description: "Пожалуйста, выберите цвет перед добавлением в корзину",
        variant: "destructive"
      });
      return;
    }
    
    addToCart(product.id, quantity, selectedVariantId || undefined);
  };
  
  // Calculate discount percentage if there's a compareAtPrice
  const discount = product?.compareAtPrice 
    ? Math.round((1 - (product.price / product.compareAtPrice)) * 100) 
    : 0;
  
  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-12 flex justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }
  
  if (!product) {
    return (
      <div className="container mx-auto px-4 py-12 text-center">
        <h1 className="text-2xl font-bold mb-4">Товар не найден</h1>
        <p className="mb-6">К сожалению, запрашиваемый товар не существует или был удален.</p>
        <Link href="/products">
          <Button>Перейти к каталогу</Button>
        </Link>
      </div>
    );
  }
  
  return (
    <div className="bg-gray-light py-6 md:py-12">
      <div className="container mx-auto px-4">
        {/* Breadcrumbs */}
        <Breadcrumb className="mb-6">
          <BreadcrumbList>
            <BreadcrumbItem>
              <BreadcrumbLink href="/">Главная</BreadcrumbLink>
              <BreadcrumbSeparator />
            </BreadcrumbItem>
            <BreadcrumbItem>
              <BreadcrumbLink href="/products">Товары</BreadcrumbLink>
              <BreadcrumbSeparator />
            </BreadcrumbItem>
            {product.category && (
              <BreadcrumbItem>
                <BreadcrumbLink href={`/products/category/${product.category.slug}`}>
                  {product.category.name}
                </BreadcrumbLink>
                <BreadcrumbSeparator />
              </BreadcrumbItem>
            )}
            <BreadcrumbItem>
              <BreadcrumbPage>{product.name}</BreadcrumbPage>
            </BreadcrumbItem>
          </BreadcrumbList>
        </Breadcrumb>
        
        {/* Product detail */}
        <div className="bg-white rounded-lg shadow-sm overflow-hidden">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 p-4 md:p-8">
            {/* Product image */}
            <div className="relative">
              <div className="aspect-square overflow-hidden rounded-lg mb-4">
                <img 
                  src={product.imageUrl} 
                  alt={product.name} 
                  className="w-full h-full object-cover"
                />
              </div>
              
              {/* Product labels */}
              <div className="absolute top-3 left-3 flex flex-col gap-2">
                {product.isNew && (
                  <span className="bg-accent text-white text-xs font-bold py-1 px-2 rounded">NEW</span>
                )}
                {discount > 0 && (
                  <span className="bg-secondary text-white text-xs font-bold py-1 px-2 rounded">-{discount}%</span>
                )}
              </div>
            </div>
            
            {/* Product info */}
            <div>
              <h1 className="text-2xl md:text-3xl font-bold mb-2">{product.name}</h1>
              
              {/* Rating */}
              {product.rating && (
                <div className="flex items-center mb-4">
                  <div className="flex items-center text-warning">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star 
                        key={star}
                        className={`h-4 w-4 ${product.rating >= star ? 'fill-current' : 'fill-none'}`}
                      />
                    ))}
                  </div>
                  <span className="ml-2 text-sm text-gray-600">{typeof product.rating === 'number' ? product.rating.toFixed(1) : product.rating}</span>
                </div>
              )}
              
              {/* Price */}
              <div className="flex items-center gap-2 mb-6">
                <span className="text-2xl font-bold">{formatCurrency(product.price)}</span>
                {product.compareAtPrice && (
                  <span className="text-gray-500 line-through">{formatCurrency(product.compareAtPrice)}</span>
                )}
              </div>
              
              {/* Description */}
              <p className="text-gray-700 mb-6">{product.description}</p>
              
              {/* Colors */}
              {colors.length > 0 && (
                <div className="mb-6">
                  <h3 className="font-medium mb-2">Цвет:</h3>
                  <div className="flex gap-2">
                    {colors.map((color: any) => (
                      <button
                        key={color.id}
                        className={`w-10 h-10 rounded-full border-2 flex items-center justify-center ${
                          selectedColorId === color.id 
                            ? 'border-primary' 
                            : 'border-gray-300'
                        }`}
                        style={{ backgroundColor: color.value }}
                        onClick={() => handleColorSelect(color.id)}
                        title={color.name}
                      >
                        {selectedColorId === color.id && <Check className="h-5 w-5 text-white stroke-2" />}
                      </button>
                    ))}
                  </div>
                </div>
              )}
              
              {/* Sizes */}
              {sizes.length > 0 && (
                <div className="mb-6">
                  <div className="flex justify-between items-center mb-2">
                    <h3 className="font-medium">Размер:</h3>
                    <Button variant="link" className="text-sm p-0 h-auto">
                      Таблица размеров
                    </Button>
                  </div>
                  <SizeSelector
                    sizes={sizes as any[]}
                    selectedSize={selectedSizeId ? String(selectedSizeId) : null}
                    onSelectSize={(sizeId) => handleSizeSelect(parseInt(sizeId))}
                  />
                </div>
              )}
              
              {/* Quantity */}
              <div className="mb-6">
                <h3 className="font-medium mb-2">Количество:</h3>
                <div className="flex items-center border border-gray-300 rounded w-32">
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-10 rounded-none px-3"
                    onClick={() => handleQuantityChange(quantity - 1)}
                    disabled={quantity <= 1}
                  >
                    <Minus className="h-4 w-4" />
                  </Button>
                  <div className="flex-1 text-center">{quantity}</div>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-10 rounded-none px-3"
                    onClick={() => handleQuantityChange(quantity + 1)}
                  >
                    <Plus className="h-4 w-4" />
                  </Button>
                </div>
              </div>
              
              {/* Actions */}
              <div className="flex flex-col sm:flex-row gap-3">
                <Button
                  size="lg"
                  className="flex-1"
                  onClick={handleAddToCart}
                >
                  Добавить в корзину
                </Button>
                <Button
                  variant="outline"
                  size="lg"
                  className="sm:w-12"
                >
                  <Heart className="h-5 w-5" />
                </Button>
              </div>
              
              {/* Availability */}
              <div className="mt-6 flex items-center">
                <div className={`w-3 h-3 rounded-full ${product.inStock ? 'bg-green-500' : 'bg-red-500'} mr-2`}></div>
                <span>{product.inStock ? 'В наличии' : 'Нет в наличии'}</span>
              </div>
            </div>
          </div>
          
          {/* Product tabs */}
          <div className="border-t p-4 md:p-8">
            <Tabs defaultValue="description">
              <TabsList className="mb-4">
                <TabsTrigger value="description">Описание</TabsTrigger>
                <TabsTrigger value="details">Характеристики</TabsTrigger>
                <TabsTrigger value="delivery">Доставка и оплата</TabsTrigger>
              </TabsList>
              <TabsContent value="description" className="min-h-[200px]">
                <div className="prose max-w-none">
                  <p>{product.description || 'Описание товара отсутствует.'}</p>
                </div>
              </TabsContent>
              <TabsContent value="details" className="min-h-[200px]">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <h3 className="font-medium mb-2">Основные характеристики</h3>
                    <ul className="space-y-2">
                      <li className="flex justify-between">
                        <span className="text-gray-600">Бренд:</span>
                        <span>FashionHub</span>
                      </li>
                      <li className="flex justify-between">
                        <span className="text-gray-600">Состав:</span>
                        <span>100% хлопок</span>
                      </li>
                      <li className="flex justify-between">
                        <span className="text-gray-600">Категория:</span>
                        <span>{product.category?.name || 'Одежда'}</span>
                      </li>
                      <li className="flex justify-between">
                        <span className="text-gray-600">Страна производства:</span>
                        <span>Россия</span>
                      </li>
                    </ul>
                  </div>
                  <div>
                    <h3 className="font-medium mb-2">Дополнительно</h3>
                    <ul className="space-y-2">
                      <li className="flex justify-between">
                        <span className="text-gray-600">Уход:</span>
                        <span>Машинная стирка при 30°C</span>
                      </li>
                      <li className="flex justify-between">
                        <span className="text-gray-600">Артикул:</span>
                        <span>{product.id}</span>
                      </li>
                      <li className="flex justify-between">
                        <span className="text-gray-600">Возврат:</span>
                        <span>30 дней</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </TabsContent>
              <TabsContent value="delivery" className="min-h-[200px]">
                <div className="space-y-4">
                  <div>
                    <h3 className="font-medium mb-2">Способы доставки</h3>
                    <ul className="list-disc ml-5 space-y-1">
                      <li>Курьерская доставка — от 350 ₽</li>
                      <li>Доставка в пункт выдачи — от 190 ₽</li>
                      <li>Почта России — от 300 ₽</li>
                    </ul>
                  </div>
                  <div>
                    <h3 className="font-medium mb-2">Способы оплаты</h3>
                    <ul className="list-disc ml-5 space-y-1">
                      <li>Оплата картой онлайн</li>
                      <li>Оплата наличными при получении</li>
                      <li>Оплата картой при получении</li>
                    </ul>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </div>
        
        {/* Related products */}
        {relatedProducts.length > 0 && (
          <div className="mt-12">
            <h2 className="text-2xl font-bold mb-6">Похожие товары</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
              {relatedProducts.map((relatedProduct: any) => (
                <ProductCard
                  key={relatedProduct.id}
                  id={relatedProduct.id}
                  name={relatedProduct.name}
                  slug={relatedProduct.slug}
                  price={relatedProduct.price}
                  compareAtPrice={relatedProduct.compareAtPrice}
                  imageUrl={relatedProduct.imageUrl}
                  rating={relatedProduct.rating}
                  isNew={relatedProduct.isNew}
                  isSale={relatedProduct.compareAtPrice && relatedProduct.compareAtPrice > relatedProduct.price}
                  sizes={relatedProduct.productVariants?.map((v: any) => v.size).filter(Boolean)}
                  colors={relatedProduct.productVariants?.map((v: any) => v.color).filter(Boolean)}
                />
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
