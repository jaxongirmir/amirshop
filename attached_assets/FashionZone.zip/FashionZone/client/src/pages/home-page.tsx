import { useState } from "react";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { CategoryCard } from "@/components/ui/category-card";
import { ProductCard } from "@/components/ui/product-card";

export default function HomePage() {
  const [activeSlideIndex, setActiveSlideIndex] = useState(0);
  const [activeTab, setActiveTab] = useState("all");

  // Fetch categories
  const { data: categories } = useQuery({
    queryKey: ["/api/categories"],
  });

  // Fetch featured products
  const { data: featuredProductsData } = useQuery({
    queryKey: ["/api/products", { isFeatured: true, limit: 4 }],
    queryFn: () => 
      fetch("/api/products?isFeatured=true&limit=4")
        .then(res => res.json())
  });

  // Fetch new arrivals
  const { data: newArrivalsData } = useQuery({
    queryKey: ["/api/products", { isNew: true, limit: 4 }],
    queryFn: () => 
      fetch("/api/products?isNew=true&limit=4")
        .then(res => res.json())
  });

  const featuredProducts = featuredProductsData?.products || [];
  const newArrivals = newArrivalsData?.products || [];

  // Filter featured products by category type
  const filteredFeaturedProducts = activeTab === "all" 
    ? featuredProducts 
    : featuredProducts.filter((product: any) => product.categoryType === activeTab);

  // Banners data
  const banners = [
    {
      id: 1,
      title: "Новая осенняя коллекция",
      description: "Откройте для себя свежие тренды и стильные новинки для прохладного сезона.",
      image: "https://images.unsplash.com/photo-1445205170230-053b83016050?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=900"
    },
    {
      id: 2,
      title: "Летняя распродажа",
      description: "Скидки до 60% на избранные летние коллекции. Спешите приобрести!",
      image: "https://images.unsplash.com/photo-1529139574466-a303027c1d8b?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=900"
    },
    {
      id: 3,
      title: "Новая коллекция аксессуаров",
      description: "Дополните свой образ стильными аксессуарами из нашей новой коллекции.",
      image: "https://images.unsplash.com/photo-1523381294911-8d3cead13475?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=900"
    }
  ];

  const mainCategories = categories?.filter((cat: any) => !cat.parentId) || [];

  return (
    <div>
      {/* Hero Banner */}
      <section className="relative overflow-hidden">
        <div className="relative h-[300px] md:h-[450px] bg-dark">
          <img 
            src={banners[activeSlideIndex].image} 
            alt={banners[activeSlideIndex].title} 
            className="absolute inset-0 w-full h-full object-cover opacity-95"
          />
          
          <div className="absolute inset-0 bg-gradient-to-r from-dark/70 to-transparent"></div>
          
          <div className="container mx-auto px-4 h-full flex items-center relative z-10">
            <div className="max-w-lg">
              <h1 className="text-3xl md:text-5xl font-bold text-white font-playfair mb-4">
                {banners[activeSlideIndex].title}
              </h1>
              <p className="text-white/90 mb-6 text-lg">
                {banners[activeSlideIndex].description}
              </p>
              <div className="flex flex-wrap gap-3">
                <Link href="/products/category/women">
                  <Button size="lg" className="px-6">Смотреть женскую</Button>
                </Link>
                <Link href="/products/category/men">
                  <Button size="lg" variant="outline" className="px-6 bg-white text-dark border-white hover:bg-gray-100">
                    Смотреть мужскую
                  </Button>
                </Link>
              </div>
            </div>
          </div>
          
          {/* Hero navigation dots */}
          <div className="absolute bottom-4 left-0 right-0 flex justify-center gap-2">
            {banners.map((banner, index) => (
              <button 
                key={banner.id}
                className={`w-2.5 h-2.5 rounded-full bg-white ${activeSlideIndex === index ? 'opacity-100' : 'opacity-50'}`}
                onClick={() => setActiveSlideIndex(index)}
                aria-label={`Go to slide ${index + 1}`}
              ></button>
            ))}
          </div>
        </div>
      </section>

      {/* Category Highlights */}
      <section className="py-12 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl md:text-3xl font-bold mb-8 text-center font-montserrat">Выберите категорию</h2>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {mainCategories.map((category: any) => (
              <CategoryCard 
                key={category.id}
                name={category.name}
                slug={category.slug}
                imageUrl={category.imageUrl}
              />
            ))}
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-12 bg-gray-light">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center mb-8">
            <h2 className="text-2xl md:text-3xl font-bold font-montserrat">Популярные товары</h2>
            
            <div className="flex mt-4 md:mt-0 space-x-2">
              <Button 
                variant={activeTab === "all" ? "default" : "outline"} 
                onClick={() => setActiveTab("all")}
                className={activeTab === "all" ? "" : "bg-white text-dark hover:bg-gray-100"}
              >
                Все
              </Button>
              <Button 
                variant={activeTab === "women" ? "default" : "outline"} 
                onClick={() => setActiveTab("women")}
                className={activeTab === "women" ? "" : "bg-white text-dark hover:bg-gray-100"}
              >
                Женщинам
              </Button>
              <Button 
                variant={activeTab === "men" ? "default" : "outline"} 
                onClick={() => setActiveTab("men")}
                className={activeTab === "men" ? "" : "bg-white text-dark hover:bg-gray-100"}
              >
                Мужчинам
              </Button>
            </div>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
            {filteredFeaturedProducts.map((product: any) => (
              <ProductCard
                key={product.id}
                id={product.id}
                name={product.name}
                slug={product.slug}
                price={product.price}
                compareAtPrice={product.compareAtPrice}
                imageUrl={product.imageUrl}
                rating={product.rating}
                isNew={product.isNew}
                isSale={product.compareAtPrice && product.compareAtPrice > product.price}
                // Add sizes and colors if available in the API
                sizes={product.productVariants?.map((v: any) => v.size).filter(Boolean)}
                colors={product.productVariants?.map((v: any) => v.color).filter(Boolean)}
              />
            ))}
          </div>
          
          <div className="mt-8 text-center">
            <Link href="/products">
              <Button variant="outline" className="px-8 py-3 border-2 border-primary">
                Смотреть все товары
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Promotion Banner */}
      <section className="py-12 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Promo Card 1 */}
            <div className="relative rounded-lg overflow-hidden hover-zoom group">
              <img src="https://images.unsplash.com/photo-1529139574466-a303027c1d8b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400" alt="Летняя распродажа" className="w-full h-[200px] md:h-[300px] object-cover" />
              <div className="absolute inset-0 bg-gradient-to-r from-dark/80 to-dark/20"></div>
              <div className="absolute inset-0 flex flex-col justify-center p-8">
                <span className="text-secondary uppercase tracking-wider text-sm font-semibold">Ограниченное предложение</span>
                <h3 className="text-2xl md:text-3xl font-bold text-white mt-2 mb-3 font-playfair">Летняя распродажа</h3>
                <p className="text-white/80 mb-4 max-w-xs">Скидки до 60% на избранные летние коллекции</p>
                <Link href="/products" className="self-start">
                  <Button variant="outline" className="bg-white text-dark border-white hover:bg-gray-100 group-hover:px-8 transition-all flex items-center">
                    Узнать больше
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </Link>
              </div>
            </div>
            
            {/* Promo Card 2 */}
            <div className="relative rounded-lg overflow-hidden hover-zoom group">
              <img src="https://images.unsplash.com/photo-1523381294911-8d3cead13475?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400" alt="Новая коллекция" className="w-full h-[200px] md:h-[300px] object-cover" />
              <div className="absolute inset-0 bg-gradient-to-r from-dark/80 to-dark/20"></div>
              <div className="absolute inset-0 flex flex-col justify-center p-8">
                <span className="text-accent uppercase tracking-wider text-sm font-semibold">Новинка</span>
                <h3 className="text-2xl md:text-3xl font-bold text-white mt-2 mb-3 font-playfair">Премиум коллекция</h3>
                <p className="text-white/80 mb-4 max-w-xs">Эксклюзивные модели из новой премиальной линейки</p>
                <Link href="/premium" className="self-start">
                  <Button variant="outline" className="bg-white text-dark border-white hover:bg-gray-100 group-hover:px-8 transition-all flex items-center">
                    Открыть коллекцию
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* New Arrivals */}
      <section className="py-12 bg-gray-light">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center mb-8">
            <h2 className="text-2xl md:text-3xl font-bold font-montserrat">Новые поступления</h2>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
            {newArrivals.map((product: any) => (
              <ProductCard
                key={product.id}
                id={product.id}
                name={product.name}
                slug={product.slug}
                price={product.price}
                compareAtPrice={product.compareAtPrice}
                imageUrl={product.imageUrl}
                rating={product.rating}
                isNew={true}
                isSale={product.compareAtPrice && product.compareAtPrice > product.price}
                // Add sizes and colors if available in the API
                sizes={product.productVariants?.map((v: any) => v.size).filter(Boolean)}
                colors={product.productVariants?.map((v: any) => v.color).filter(Boolean)}
              />
            ))}
          </div>
        </div>
      </section>
      
      {/* Advantages Section */}
      <section className="py-12 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl md:text-3xl font-bold mb-10 text-center font-montserrat">Почему выбирают нас</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {/* Advantage Item */}
            <div className="flex flex-col items-center text-center">
              <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                <i className="fas fa-truck text-primary text-2xl"></i>
              </div>
              <h3 className="font-bold text-lg mb-2">Быстрая доставка</h3>
              <p className="text-gray-600">Доставляем заказы от 1 до 3 рабочих дней по всей России</p>
            </div>
            
            {/* Advantage Item */}
            <div className="flex flex-col items-center text-center">
              <div className="w-16 h-16 rounded-full bg-secondary/10 flex items-center justify-center mb-4">
                <i className="fas fa-medal text-secondary text-2xl"></i>
              </div>
              <h3 className="font-bold text-lg mb-2">Гарантия качества</h3>
              <p className="text-gray-600">Мы тщательно отбираем поставщиков и проверяем качество товаров</p>
            </div>
            
            {/* Advantage Item */}
            <div className="flex flex-col items-center text-center">
              <div className="w-16 h-16 rounded-full bg-accent/10 flex items-center justify-center mb-4">
                <i className="fas fa-undo text-accent text-2xl"></i>
              </div>
              <h3 className="font-bold text-lg mb-2">Легкий возврат</h3>
              <p className="text-gray-600">30 дней на возврат, если товар не подошел или не понравился</p>
            </div>
            
            {/* Advantage Item */}
            <div className="flex flex-col items-center text-center">
              <div className="w-16 h-16 rounded-full bg-success/10 flex items-center justify-center mb-4">
                <i className="fas fa-headset text-green-600 text-2xl"></i>
              </div>
              <h3 className="font-bold text-lg mb-2">Поддержка 24/7</h3>
              <p className="text-gray-600">Наша служба поддержки всегда на связи и готова помочь</p>
            </div>
          </div>
        </div>
      </section>

      {/* Instagram Feed */}
      <section className="py-12 bg-gray-light">
        <div className="container mx-auto px-4">
          <div className="flex flex-col items-center mb-8">
            <h2 className="text-2xl md:text-3xl font-bold mb-3 text-center font-montserrat">Мы в Instagram</h2>
            <p className="text-gray-600 text-center max-w-2xl">Подписывайтесь на наш Instagram, чтобы быть в курсе новых коллекций, акций и событий</p>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
            {/* Instagram posts */}
            <a href="#" className="block relative group overflow-hidden">
              <img src="https://images.unsplash.com/photo-1485968579580-b6d095142e6e?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=200" alt="Instagram post" className="w-full aspect-square object-cover" />
              <div className="absolute inset-0 bg-dark/0 group-hover:bg-dark/40 transition-all flex items-center justify-center opacity-0 group-hover:opacity-100">
                <i className="fab fa-instagram text-white text-2xl"></i>
              </div>
            </a>
            
            <a href="#" className="block relative group overflow-hidden">
              <img src="https://images.unsplash.com/photo-1496747611176-843222e1e57c?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=200" alt="Instagram post" className="w-full aspect-square object-cover" />
              <div className="absolute inset-0 bg-dark/0 group-hover:bg-dark/40 transition-all flex items-center justify-center opacity-0 group-hover:opacity-100">
                <i className="fab fa-instagram text-white text-2xl"></i>
              </div>
            </a>
            
            <a href="#" className="block relative group overflow-hidden">
              <img src="https://images.unsplash.com/photo-1509631179647-0177331693ae?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=200" alt="Instagram post" className="w-full aspect-square object-cover" />
              <div className="absolute inset-0 bg-dark/0 group-hover:bg-dark/40 transition-all flex items-center justify-center opacity-0 group-hover:opacity-100">
                <i className="fab fa-instagram text-white text-2xl"></i>
              </div>
            </a>
            
            <a href="#" className="block relative group overflow-hidden">
              <img src="https://images.unsplash.com/photo-1584273143981-41c073dfe8f8?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=200" alt="Instagram post" className="w-full aspect-square object-cover" />
              <div className="absolute inset-0 bg-dark/0 group-hover:bg-dark/40 transition-all flex items-center justify-center opacity-0 group-hover:opacity-100">
                <i className="fab fa-instagram text-white text-2xl"></i>
              </div>
            </a>
            
            <a href="#" className="block relative group overflow-hidden">
              <img src="https://pixabay.com/get/g271b41db504c26994611ed3fb2c4a0df9bdf161e8bbf4c0a445f8c48ce07d4d686e5145fabfa439d3552aa3ab508b4281d9eb6fdaf85a4188234cdb4510e01c7_1280.jpg" alt="Instagram post" className="w-full aspect-square object-cover" />
              <div className="absolute inset-0 bg-dark/0 group-hover:bg-dark/40 transition-all flex items-center justify-center opacity-0 group-hover:opacity-100">
                <i className="fab fa-instagram text-white text-2xl"></i>
              </div>
            </a>
            
            <a href="#" className="block relative group overflow-hidden">
              <img src="https://images.unsplash.com/photo-1529139574466-a303027c1d8b?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=200" alt="Instagram post" className="w-full aspect-square object-cover" />
              <div className="absolute inset-0 bg-dark/0 group-hover:bg-dark/40 transition-all flex items-center justify-center opacity-0 group-hover:opacity-100">
                <i className="fab fa-instagram text-white text-2xl"></i>
              </div>
            </a>
          </div>
          
          <div className="mt-8 text-center">
            <a href="#" className="flex items-center justify-center gap-2 mx-auto text-lg font-medium text-dark hover:text-primary transition">
              <span>@fashionhub</span>
              <i className="fab fa-instagram"></i>
            </a>
          </div>
        </div>
      </section>

      {/* Newsletter */}
      <section className="py-12 bg-dark text-white">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-2xl md:text-3xl font-bold mb-3 font-montserrat">Подпишитесь на новости</h2>
            <p className="text-white/80 mb-8">Будьте первыми, кто узнает о новых коллекциях, специальных предложениях и эксклюзивных акциях</p>
            
            <form className="flex flex-col md:flex-row gap-3">
              <input 
                type="email" 
                placeholder="Ваш email" 
                className="flex-grow py-3 px-4 rounded-md focus:outline-none focus:ring-2 focus:ring-primary text-dark"
                required
              />
              <Button className="py-3 px-6 font-medium whitespace-nowrap">
                Подписаться
              </Button>
            </form>
            
            <p className="text-white/60 text-sm mt-4">
              Подписываясь, вы соглашаетесь с нашей <Link href="/privacy" className="underline hover:text-white">Политикой конфиденциальности</Link>
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}
